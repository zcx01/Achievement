from setuptools import setup, find_packages
import os
data_files_list = []
if os.path.exists('mega_cantools_lib/signal_monitor/signal_monitor.so'):
    data_files_list = [
        ('mega_cantools_lib/parsers', ['mega_cantools_lib/parsers/monitor.so',
                                       'mega_cantools_lib/parsers/monkey.so',
                                       'mega_cantools_lib/parsers/canlog_editor.so']),
        ('mega_cantools_lib/can_log', ['mega_cantools_lib/can_log/editor_wrapper.so']),
        ('mega_cantools_lib/ecu_simulator', ['mega_cantools_lib/ecu_simulator/simulator.so']),
        ('mega_cantools_lib/signal_monitor', ['mega_cantools_lib/signal_monitor/signal_monitor.so',
                                              'mega_cantools_lib/signal_monitor/signal_monkey.so',
                                              'mega_cantools_lib/signal_monitor/signal_plot.so',
                                              'mega_cantools_lib/signal_monitor/data_saver_manager.so',
                                              'mega_cantools_lib/signal_monitor/socketcan_wrapper.so']),
    ]

setup(
    name='mega_cantools_lib',
    version='3.2.9',
    description='mega cantools lib include diagnostics, ecu_simulator and signal_monitor',
    author='augan.zhang',
    author_email='aguan.zhang@megatronix.co',
    url='https://com.megatronix.com/',
    packages = ['mega_cantools_lib', 'mega_cantools_lib/parsers', 'mega_cantools_lib/can_log', 'mega_cantools_lib/dbc_files', 'mega_cantools_lib/can_load', 'mega_cantools_lib/ecu_simulator', 'mega_cantools_lib/ecu_simulator/ecu_json','mega_cantools_lib/signal_monitor'],
    package_data = {
        # If any package contains *.ini or *.sh files, include them:
        'mega_cantools_lib': ['*.ini', '*.sh', '*.md', '*.dbc'],
        'mega_cantools_lib/dbc_files': ['*.dbc', '*.ini'],
        'mega_cantools_lib/can_load': ['*.sh'],
        'mega_cantools_lib/ecu_simulator/ecu_json': ['*.json'],
        'mega_cantools_lib/signal_monitor': ['*.ini']
    },
    install_requires=['python-can==3.3.4', 'cantools==34.0.0'],
    data_files=data_files_list,
    entry_points = {'console_scripts': ['megamonitor=mega_cantools_lib.test_monitor:main',
                                        'megacangen=mega_cantools_lib.test_cangen:main',
                                        'megacanlog=mega_cantools_lib.test_canlog:main']},
    zip_safe=False)