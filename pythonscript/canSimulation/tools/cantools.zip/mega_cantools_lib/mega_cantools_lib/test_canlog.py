# -*- coding: utf-8 -*-

"""
A canlog record/replay tools.
1. Record can messages to a blf file.
2. Plays back messages in blf/csv file in the recorded order with an time intervals.
   it can filter can frames to play.
3. Convert blf file to csv format.
"""

import os
import argparse
from mega_cantools_lib.parsers.canlog_editor import _canlog


def main():
    parser = argparse.ArgumentParser(
        description='mega blf record/replay tools.'
                    '1. Record can messages receiced by PCAN to a blf file.'
                    '2. Plays back messages in blf file in the recorded order with an time intervals.'
                    '3. Covert blf to csv')

    parser.add_argument('-b', '--bustype',
                        help='specify bustype, support can and canfd',
                        default='canfd')

    parser.add_argument("--folder",
                        help='specific can log saved folder',
                        default='/tmp')

    parser.add_argument('-c', '--channel',
                        type=int,
                        help='specify can channel',
                        default=0)

    parser.add_argument('-v', action="count", dest="verbosity",
                        help='''Also print can frames to stdout.
                        You can add several of these to enable debugging''',
                        default=False)

    parser.add_argument('--record',
                        help='Record receiced can messages to a blf file',
                        action='store_true')

    parser.add_argument("-d", "--duration",
                        type=int,
                        help="specify seconds length when recording. default: 600s",
                        default=600)

    parser.add_argument('--replay',
                        help='Replay BLF file to CAN bus')

    parser.add_argument('-f', '--filter',
                        help='filter the can frames(decimalism) to replay. format:608,609,610, default:None',
                        default=None)

    parser.add_argument('-r', "--recycle",
                        help='recycle play can log',
                        default=True)

    parser.add_argument('-g', '--gaps',
                        help='specify waiting gaps between message, default is 0',
                        default=0)

    parser.add_argument('--tocsv', help='convert .blf data to output.csv')

    args = parser.parse_args()
    _canlog(args)

