# -*- coding: utf-8 -*-
"""
A can Generate (random) CAN traffic to CDC
"""

import sys
import os
sys.path.append(os.path.dirname(os.path.abspath(__file__))+'/../../')
from mega_cantools_lib.signal_monitor.signal_monkey import SignalMonkey
import time
def _monkey(args):
    if args.get:
        monkey = SignalMonkey()
        monkey.get_all_node()
    else:
        monkey_type = 'random' if args.random else 'init'
        args.node.split(',')
        monkey_node = args.node.split(',')
        print("Monkey test will simulate {} nodes to send can frame data.".format(monkey_node))
        monkey = SignalMonkey(project=args.project,
                              channel=args.channel,
                              random_value=monkey_type,
                              random_periodic=args.randomcycle,
                              test_time=int(args.time),
                              monkey_node=monkey_node,
                              monkey_file=args.file)

        monkey.monkey_test()
        time.sleep(2)
        monkey.get_frame_counts()
