# -*- coding: utf-8 -*-
"""
A can signal monitor tool.
1. send can signals to CDC periodic.
2. listened signals/message changes.
3. plot signal changing in real-time
"""

import sys
import os
sys.path.append(os.path.dirname(os.path.abspath(__file__))+'/../../')
from collections import OrderedDict
from mega_cantools_lib.signal_monitor.signal_monitor import SignalMonitor
from mega_cantools_lib.ecu_simulator.simulator import MonitorSignal

def _monitor(args):
    rcv_specific_sig = []
    rcv_sibling_sigs = []
    send_specific_sig = OrderedDict()

    if args.json:
        monitor = MonitorSignal(args.json)
        monitor.begin_monitor()
    else:
        for i in range(len(sys.argv)):
            if sys.argv[i] == '-l':
                rcv_specific_sig.append(sys.argv[i + 1])
            if sys.argv[i] == '-lm':
                rcv_sibling_sigs.append(sys.argv[i + 1])
            if sys.argv[i] == '-s' and sys.argv[i + 2] == '-v':
                send_specific_sig[sys.argv[i + 1]] = sys.argv[i + 3]
            if sys.argv[i] == '-s' and sys.argv[i + 2] != '-v':
                print('please assign the signal values behind the signal {}'
                      .format(sys.argv[i + 1]))

        monitor = SignalMonitor(args.channel,
                                rcv_sibling_sigs,
                                rcv_specific_sig,
                                send_specific_sig,
                                '1',
                                project=args.project,
                                dbc=args.dbc,
                                ignore_init_sending=args.ignore,
                                decode_choices=args.decode)
        monitor.begin_monitor(args.plot)