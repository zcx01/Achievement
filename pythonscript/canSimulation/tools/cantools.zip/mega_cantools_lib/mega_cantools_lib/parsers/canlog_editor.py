# -*- coding: utf-8 -*-

"""
A mega blf record/replay tools.
1. Record can messages  to a blf file.
2. Plays back messages in blf file in the recorded order with an time intervals.
   it can filter can frames to play.
3. Convert blf file to csv format.
"""

import os
import sys
import csv
import argparse
import can
sys.path.append(os.path.dirname(os.path.abspath(__file__))+'/../../')
from mega_cantools_lib.can_log.editor_wrapper import CanLogWrapper

def _canlog(args):
    cur_path = args.folder
    can_app = CanLogWrapper(channel=args.channel, busType=args.bustype)

    logging_level_name = ['critical', 'error', 'warning', 'info', 'debug', 'subdebug'][min(5, args.verbosity)]
    can.set_logging_level(logging_level_name)

    if args.replay:
        replay_file_path = os.path.join(cur_path, args.replay)
        can_app.play(replay_file_path, args.recycle, args.gaps,
                         args.filter,  args.verbosity)

    if args.record:
        can_app.record(args.duration, cur_path)

    if args.tocsv:
        tocsv_file_path = os.path.join(cur_path, args.tocsv)
        can_log = can_app.blf2csv(tocsv_file_path, args.filter)
        with open('output.csv', 'w', newline='') as f:
            writer = csv.writer(f, delimiter='\t', quotechar='"',
                                quoting=csv.QUOTE_ALL)
            writer.writerows(can_log)
