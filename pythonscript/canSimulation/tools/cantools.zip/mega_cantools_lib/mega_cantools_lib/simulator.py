# -*- coding: utf-8 -*-
"""
Mega ECU Simulator tools.
1. only support hvac signals or carsettings signals.
"""

import argparse
import sys
from ecu_simulator.ecu_simulator import MonitorSignal

if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=" signal simulator tools")

    parser.add_argument('-e', "--ecu",
                        help="which ecu to simulator (hvac, carsettings)")

    args = parser.parse_args()
    if args.ecu in ('hvac', 'carsettings'):
        monitor = MonitorSignal(args.ecu)
        monitor.begin_monitor()
    else:
        print('only support hvac and carsettings')