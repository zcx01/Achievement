from udsoncan.connections import PythonIsoTpConnection
from udsoncan.services import DiagnosticSessionControl
from udsoncan.services import ECUReset
from udsoncan.client import Client
from udsoncan import AsciiCodec
from udsoncan import DidCodec
from udsoncan import configs
from udsoncan import exceptions
from udsoncan import setup_logging
import isotp
import can
import struct

'''
class: UDS_Client(ECU)
    param :ECU: specific ECU type, default: CDC.
           only support CDC and TGW.
function:
    enter_extendedMode()
    enter_defaultMode()
    reset_ecu()
    write_did(did, value)
    read_did(did)
    request_seeds(level)
    send_keys(level, key)
    get_dtcs()
    clear_dtc()
'''
class uds_config():
    def __init__(self, ECU = 'CDC'):
        if str.upper(ECU) == 'CDC':
            self.config = {
                0x0100: [DidCodec('BBBBBBBBBBBBBBBB'), 'to_hex_string'],
                0x0101: [DidCodec('BBBBBBBBBBBBBBBB'), 'to_hex_string'],
                0x0102: [DidCodec('BBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBB'), 'to_hex_string'],
                0x0103: [DidCodec('BBBBBBBB'), 'to_hex_string'],
                0xf193: [AsciiCodec(8), 'to_ascii'],
                0x0110: [DidCodec('B'), 'to_hex'],
                0xF190: [AsciiCodec(17), 'to_ascii'],
                0xF17F: [AsciiCodec(17), 'to_ascii'],
                0xF189: [AsciiCodec(17), 'to_ascii'],
                0xF195: [DidCodec('HHHH'), 'to_version'],
                0x0E3B: [DidCodec('HHHH'), 'to_version'],
    
                0xF186: [DidCodec('B'), 'to_hex'],
                0xF187: [AsciiCodec(14), 'to_ascii'],
                0xF18C: [DidCodec('IIII'), 'to_hex_string'],
                0x0120: [DidCodec('BBBBBBBBBBBBBBBBBBBBBBBBB'), 'to_hex_string'],
                0x0140: [DidCodec('B'), 'to_hex'],
                0x0200: [AsciiCodec(2), 'to_hex_string'],
                0x0201: [AsciiCodec(2), 'to_hex_string'],
                0xF100: [AsciiCodec(2), 'to_hex_string'],
                0xF101: [AsciiCodec(3), 'to_hex_string'],
                0xF102: [AsciiCodec(17), 'to_hex_string'],
                0xF10B: [AsciiCodec(4), 'to_ascii'],
                0xF10D: [AsciiCodec(3), 'to_hex_string'],
    
                0xF180: [AsciiCodec(17), 'to_ascii'],
                0xF181: [AsciiCodec(17), 'to_ascii'],
                0xF184: [DidCodec('BBBBBBBBBB'), 'to_hex_string'],
                0xF18A: [AsciiCodec(9), 'to_hex_string'],
                0xF18E: [AsciiCodec(14), 'to_ascii'],
    
                0xF197: [AsciiCodec(20), 'to_ascii'],
                0xF199: [AsciiCodec(4), 'to_hex_string'],
                0xF1B2: [AsciiCodec(17), 'to_ascii'],
    
                0x0300: [AsciiCodec(128), 'to_hex_string'],
                0x0301: [AsciiCodec(128), 'to_hex_string'],
                0x0302: [AsciiCodec(128), 'to_hex_string'],
                0x0303: [AsciiCodec(128), 'to_hex_string'],
                0x0305: [AsciiCodec(4), 'to_hex_string'],
    
                0x0E0E: [AsciiCodec(7), 'to_time'],
                0x0E0F: [DidCodec('B'), 'to_hex'],
                0x0E10: [DidCodec('B'), 'to_hex'],
                0x0E11: [DidCodec('B'), 'to_hex'],
                0x0E12: [DidCodec('B'), 'to_hex'],
                0x0E13: [DidCodec('B'), 'to_hex'],
                0x0E14: [DidCodec('B'), 'to_hex'],
                0x0E15: [DidCodec('B'), 'to_hex'],
                0x0E16: [DidCodec('B'), 'to_hex'],
                0x0E17: [DidCodec('B'), 'to_hex'],
                0x0E18: [DidCodec('B'), 'to_hex'],
                0x0E19: [DidCodec('B'), 'to_hex'],
                0x0E1A: [DidCodec('B'), 'to_hex'],
    
                0x0E1B: [AsciiCodec(15), 'to_hex_string'],
                0x0E1C: [AsciiCodec(15), 'to_hex_string'],
                0x0E1D: [DidCodec('B'), 'to_hex'],
                0x0E1E: [DidCodec('B'), 'to_hex'],
                0x0E1F: [AsciiCodec(10), 'to_hex_string']
            }
        elif str.upper(ECU) == 'TGW':
            self.config = {
                0x0100: [DidCodec('BBBBBBBBBBBBBBBB'), 'to_hex_string'],
                0x0101: [DidCodec('BBBBBBBBBBBBBBBB'), 'to_hex_string'],
                0x0102: [DidCodec('BBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBB'), 'to_hex_string'],
                0xf193: [AsciiCodec(8), 'to_ascii'],
                0x0110: [DidCodec('B'), 'to_hex'],
                0xF190: [AsciiCodec(17), 'to_ascii'],
                0xF17F: [AsciiCodec(17), 'to_ascii'],
                0xF189: [AsciiCodec(17), 'to_ascii'],
                0xF195: [DidCodec('HHHH'), 'to_version'],
                0x0E3B: [DidCodec('HHHH'), 'to_version'],

                0xF186: [DidCodec('B'), 'to_hex'],
                0xF187: [AsciiCodec(14), 'to_ascii'],
                0xF18C: [DidCodec('IIII'), 'to_comp'],
                0x0120: [DidCodec('BBBBBBBBBBBBBBBBBBBBBBBBB'), 'to_hex_string'],
                0x0140: [DidCodec('B'), 'to_hex'],
                 
                0x0E20: [AsciiCodec(16), 'to_ascii'],
                0x0E21: [DidCodec('B'), 'to_hex'],
                0x0E24: [AsciiCodec(16), 'to_ascii'],
                0x0E00: [AsciiCodec(20), 'to_ascii'],
                0x0E01: [AsciiCodec(15), 'to_ascii'],
                0x0E02: [AsciiCodec(20), 'to_ascii'],
            }
        else:
            self.config = {}
            
    def get_config(self):
        config_dict = {}
        for did, info in self.config.items():
            config_dict[did] = info[0]
        return config_dict
    
    def parse_response(self, did, st):
        resp_type = 'to_ascii'
        for DID in self.config.keys():
            if DID == did:
                resp_type = self.config[DID][1]
                break
        if resp_type == 'to_version':
            ver_list = struct.unpack(">HHHH", st)
            return "{}.{}.{}.{}".format(ver_list[0], ver_list[1], ver_list[2], ver_list[3])
       
        elif resp_type == 'to_time':
            ret = ' '.join('{:02x}'.format(x) for x in st)
            return "{}{}-{}-{} {}:{}:{}".format(ret[0:2], ret[3:5], ret[6:8], ret[9:11], ret[12:14], ret[15:17],
                                                ret[18:20])
        
        elif did == 'to_comp':
            hex_data = ' '.join('{:02x}'.format(x) for x in st[:8])
            asc_data = st[8:].decode('utf-8')
            return str.upper(hex_data) + str.upper(asc_data)
        
        elif resp_type == 'to_hex':
            ver_list = struct.unpack(">B", st)
            ret = ''.join('{:02x}'.format(ver_list[0]))
            return str.upper(ret)

        elif did == None or resp_type == 'to_hex_string':
            ret = ' '.join('{:02x}'.format(x) for x in st)
            return str.upper(ret)

        else:
            return st.decode('utf-8')

class UDS_Client():
    def __init__(self, ECU, chal='can0'):
        channel = chal
        addr = 0x72d if str.upper(ECU) == 'TGW' else 0x72b
        #setup_logging()
        # Refer to isotp documentation for full details about parameters
        isotp_params = {
            'stmin': 32,  # Will request the sender to wait 32ms between consecutive frame. 0-127ms or 100-900ns with values from 0xF1-0xF9
            'blocksize': 8,  # Request the sender to send 8 consecutives frames before sending a new flow control message
            'wftmax': 0,  # Number of wait frame allowed before triggering an error
            'll_data_length': 8,  # Link layer (CAN layer) works with 8 byte payload (CAN 2.0)
            'tx_padding': 0,  # Will pad all transmitted CAN messages with byte 0x00. None means no padding
            'rx_flowcontrol_timeout': 1000,  # Triggers a timeout if a flow control is awaited for more than 1000 milliseconds
            'rx_consecutive_frame_timeout': 1000,  # Triggers a timeout if a consecutive frame is awaited for more than 1000 milliseconds
            'squash_stmin_requirement': False  # When sending, respect the stmin requirement of the receiver. If set to True, go as fast as possible.
        }
        self.status_mask = 0xb
        self.uds_apps = uds_config(ECU)
        self.config = dict(configs.default_client_config)
        self.config['data_identifiers'] = self.uds_apps.get_config()
        
        bus = can.interface.Bus(channel=channel, bitrate=500000, bustype="socketcan")
        tp_addr = isotp.Address(isotp.AddressingMode.Normal_11bits, txid=addr, rxid=addr + 0x80)
        stack = isotp.CanStack(bus=bus, address=tp_addr, params=isotp_params)
        self.conn = PythonIsoTpConnection(stack)

    def enter_extendedMode(self):
        with Client(self.conn, request_timeout=2) as client:
            client.set_configs(self.config)
            try:
                resp = None
                ret = 'no response in time'
                resp = client.change_session(DiagnosticSessionControl.Session.extendedDiagnosticSession)
                ret = self.uds_apps.parse_response(None, resp.get_payload())
            except exceptions.NegativeResponseException as e:
                print("enter extended mode in failure with exception %s" % e)
                ret = e
            finally:
                if resp and resp.positive:
                    print("enter extended mode in success")
                else:
                    print("enter extended mode in failure")
                return ret

    def enter_defaultMode(self):
        with Client(self.conn, request_timeout=2) as client:
            client.set_configs(self.config)
            try:
                resp = None
                ret = 'no response in time'
                resp = client.change_session(DiagnosticSessionControl.Session.defaultSession)
                ret = self.uds_apps.parse_response(None, resp.get_payload())
            except exceptions.NegativeResponseException as e:
                print("enter default mode in failure with exception %s" % e)
                ret = e
            finally:
                if resp and resp.positive:
                    print("enter default mode in success")
                return ret

    def reset_ecu(self):
        with Client(self.conn, request_timeout=2) as client:
            try:
                resp = None
                ret = 'no response in time'
                resp = client.ecu_reset(ECUReset.ResetType.hardReset)  # HardReset = 0x01
                ret = self.uds_apps.parse_response(None, resp.get_payload())

            except exceptions.NegativeResponseException as e:
                print("reset ecu in failure with exception %s" % e)
                ret = 'negative response (' + str(hex(e.response.code)) + ')'
            finally:
                if resp and resp.positive:
                    print("reset ecu in success")
                else:
                    print("reset ecu in failure")
                return ret

    def write_did(self, did, val):
        with Client(self.conn, request_timeout=2) as client:
            client.set_configs(self.config)
            if did in self.config['data_identifiers']:
                try:
                    resp = None
                    ret = 'no response in time'
                    resp = client.write_data_by_identifier(did, val)
                    ret = self.uds_apps.parse_response(None, resp.get_payload())
                except exceptions.NegativeResponseException as e:
                    print("write DID in failure with exception")
                    print('Server refused our request for service %s with code "%s" (0x%02x)' % (
                        e.response.service.get_name(), e.response.code_name, e.response.code))
                    ret = 'negative response (' + str(hex(e.response.code)) + ')'
                except exceptions.InvalidResponseException or exceptions.UnexpectedResponseException as e:
                    print('Server sent an invalid payload : %s' % e.response.original_payload)
                    ret = 'invalid response (' + str(hex(e.response.code)) + ')'
                except exceptions.TimeoutException as e:
                    print('Server read timeout: %s' % e)
                    ret = 'timeout response ()' + str(e)
                finally:
                    if resp and resp.positive:
                        print("write DID in success")
                    else:
                        print("write DIDin failure")
                    return ret
            else:
                print("Not in config list......")

    def read_did(self, did):
        with Client(self.conn, request_timeout=2) as client:
            client.set_configs(self.config)
            if did in self.config['data_identifiers']:
                try:
                    resp = None
                    ret = 'unknown response'
                    resp = client.read_data_by_identifier([did])
                    ret = self.uds_apps.parse_response(did, resp.get_payload()[3:]).strip()

                except exceptions.NegativeResponseException as e:
                    print('Server refused our request for service %s with code "%s" (0x%02x)' % (
                        e.response.service.get_name(), e.response.code_name, e.response.code))
                    ret = 'negative response (' + str(hex(e.response.code)) + ')'

                except exceptions.InvalidResponseException or exceptions.UnexpectedResponseException as e:
                    print('Server sent an invalid payload : %s' % e.response.original_payload)
                    ret = 'invalid response (' + str(hex(e.response.code)) + ')'

                except exceptions.TimeoutException as e:
                    print('timeout exception, %s' % e)
                    ret = 'timeout response ()' + str(e)

                finally:
                    if resp and resp.positive:
                        print("read DID in success")
                    else:
                        print("read DID in failure")
                    return ret
            else:
                print("Not in config list..")

    def request_seeds(self, level):
        with Client(self.conn, request_timeout=2) as client:
            try:
                resp = None
                ret = 'unknown response'
                resp = client.request_seed(level)
                ret = self.uds_apps.parse_response(None, resp.get_payload())

            except exceptions.NegativeResponseException as e:
                print("request seed in failure with exception")
                print('Server refused our request for service %s with code "%s" (0x%02x)' % (
                    e.response.service.get_name(), e.response.code_name, e.response.code))
                ret = 'negative response (' + str(hex(e.response.code)) + ')'
            except exceptions.InvalidResponseException or exceptions.UnexpectedResponseException as e:
                print('Server sent an invalid payload : %s' % e.response.original_payload)
                ret = 'invalid response (' + str(hex(e.response.code)) + ')'
            except exceptions.TimeoutException as e:
                print('Server read timeout: %s' % e)
                ret = 'timeout response ()' + str(e)

            finally:
                if resp and resp.positive:
                    print("request seed in success")
                else:
                    print("request seed in failure")
                return ret

    def send_keys(self, level, key):
        with Client(self.conn, request_timeout=2) as client:

            try:
                resp = None
                ret = 'unknown resp'
                resp = client.send_key(level, struct.pack(">I", key))
                ret = self.uds_apps.parse_response(None, resp.get_payload())

            except exceptions.NegativeResponseException as e:
                print("send key in failure with exception")
                print('Server refused our request for service %s with code "%s" (0x%02x)' % (
                    e.response.service.get_name(), e.response.code_name, e.response.code))
                ret = 'negative response (' + str(hex(e.response.code)) + ')'
            except exceptions.InvalidResponseException or exceptions.UnexpectedResponseException as e:
                print('Server sent an invalid payload : %s' % e.response.original_payload)
                ret = 'invalid response (' + str(hex(e.response.code)) + ')'
            except exceptions.TimeoutException as e:
                print('Server read timeout: %s' % e)
                ret = 'timeout response ()' + str(e)

            finally:
                if resp and resp.positive:
                    print("send key in success")
                else:
                    print("send key in failure")
                return ret

    def get_dtcs(self):
        with Client(self.conn, request_timeout=2) as client:
            client.set_configs(self.config)
            client.tester_present()
            try:
                resp = None
                ret = 'unknown resp'
                resp = client.get_dtc_by_status_mask(self.status_mask)
                ret = resp.service_data.dtcs
            except exceptions.NegativeResponseException as e:
                print("send key in failure with exception")
                print('Server refused our request for service %s with code "%s" (0x%02x)' % (
                    e.response.service.get_name(), e.response.code_name, e.response.code))
                ret = 'negative response (' + str(hex(e.response.code)) + ')'
            except exceptions.InvalidResponseException or exceptions.UnexpectedResponseException as e:
                print('Server sent an invalid payload : %s' % e.response.original_payload)
                ret = 'invalid response (' + str(hex(e.response.code)) + ')'
            except exceptions.TimeoutException as e:
                print('Server read timeout: %s' % e)
                ret = 'timeout response ()' + str(e)
                print("send key in failure with exception")
                print('Server refused our request for service %s with code "%s" (0x%02x)' % (
                    e.response.service.get_name(), e.response.code_name, e.response.code))
                ret = 'negative response (' + str(hex(e.response.code)) + ')'
            finally:
                if resp and resp.positive:
                    print('get dtcs in success')
                else:
                    print('get dtcs in failure')
                return ret

    def clear_dtc(self):
        with Client(self.conn, request_timeout=2) as client:
            try:
                resp = None
                ret = 'no response in time'
                resp = client.clear_dtc()
                ret = self.uds_apps.parse_response(None, resp.get_payload())
            except exceptions.NegativeResponseException as e:
                print("get dtcs in failure with exception %s" % e)
                ret = e
            finally:
                if resp and resp.positive:
                    print('clear dtc success:{} '.format(ret))
                return ret