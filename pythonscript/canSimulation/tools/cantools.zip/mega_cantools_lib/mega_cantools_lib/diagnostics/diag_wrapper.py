import os
import sys
import time
import getpass
sys.path.append(os.path.dirname(os.path.abspath(__file__))+'/../../')
from mega_cantools_lib.diagnostics.uds_client import UDS_Client


cur_path = os.path.dirname(os.path.abspath(__file__))
can_enable_path = os.path.join(cur_path, "../can_load/enable_socketcan.sh")
can_disable_path = os.path.join(cur_path, "../can_load/disable_socketcan.sh")

class Diag_wrapper():
    def __init__(self, ecu = 'CDC', channel = 'can0'):
        self.channel = channel
        self.setup()
        self.uds_app = UDS_Client(ecu, channel)

    def setup(self):
        if self.channel not in str(os.popen('ifconfig |grep can').readlines()):
            enable_socketcan = "sudo bash " + can_enable_path
            pwd = getpass.getpass("Please input your password:")
            os.system('echo {}|sudo -S {}'.format(pwd, enable_socketcan))
            time.sleep(0.1)

    def teardown(self):
        enable_socketcan = "sudo bash " + can_disable_path
        pwd = getpass.getpass("Please input your password:")
        os.system('echo {}|sudo -S {}'.format(pwd, enable_socketcan))

    def did_factory(self, args):
        did = int(args[0], 16)
        value_str = args[1]
        if did in (0x0100, 0x0101) and len(value_str) == 32 or \
                did == 0x0102 and len(value_str) == 96 or \
                did == 0x0103 and len(value_str) == 16 or \
                did == 0x0120 and len(value_str) == 50 or \
                did == 0xF184 and len(value_str) == 20:
            value = ()
            while len(value_str) > 0:
                item = int(value_str[:2], 16)
                value = value + (item,)
                value_str = value_str[2:]
            return (did, value)

        elif did in (0x0110, 0x0140) and len(value_str) == 2:
            return (did, int(value_str, 16))

        elif  did == 0x0F190 and len(value_str) == 17:
            return (did, value_str)

        else:
            print('wrong value length or unsupported did')
            sys.exit()

    def read_did(self, did):
        return self.uds_app.read_did(int(did, 16))

    def write_did(self, did_val_list):
        (did, value) = self.did_factory(did_val_list)
        self.uds_app.enter_extendedMode()
        return self.uds_app.write_did(did, value)

    def clear_ttc(self):
        self.uds_app.enter_extendedMode()
        return self.uds_app.clear_dtc()

    def get_dtc(self):
        self.uds_app.enter_extendedMode()
        dtc_list = self.uds_app.get_dtcs()
        if len(dtc_list) == 0:
            print('no dtc')
        else:
            return dtc_list

    def reset_ecu(self):
        return self.uds_app.reset_ecu()

