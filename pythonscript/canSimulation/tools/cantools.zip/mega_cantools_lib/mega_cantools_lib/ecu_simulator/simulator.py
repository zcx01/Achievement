# -*- coding: utf-8 -*-
import os
import sys
import queue
import asyncio
import json
from threading import Thread
import logging
import json
logging.basicConfig(level=logging.INFO)
import configparser
from collections import OrderedDict
import getpass
global_queue = queue.Queue()
sys.path.append(os.path.dirname(os.path.abspath(__file__))+'/../../')
from mega_cantools_lib.signal_monitor.socketcan_wrapper import SocketCANApp

class MonitorSignal(object):
    """
    The :class:`MonitorSignal` object is used to send or receive CAN message.

    func:`onSignalUpdate` is the callback function who can monitor the signals
    change.

    func:`signalOperator` is a async interface to send and receive specify signals.
    The :class:`SignalSaver` can save the signal and values by listened to csv.

    """
    def __init__(self, ecu_path):
        json_path = ecu_path
        self.listened_sig_list = []

        if json_path and os.path.splitext(json_path)[1] == '.json' and os.path.isfile(json_path):
            print(json_path)
            with open(json_path, 'r') as json_file:
                json_content = json_file.read()
                json_dict = json.loads(json_content, object_pairs_hook=OrderedDict)
                self.send_groups = json_dict['groups']
                self.pre_sigs = json_dict['pre_sig']

                logging.info("name: %s ,Pre-signals: %s", json_dict['description'],json.dumps(self.pre_sigs))
                for send_group in self.send_groups:
                    for sig_name in send_group['output_sig'].keys():
                        self.listened_sig_list.append(str(sig_name))
                self.listened_sig_list = list(set(self.listened_sig_list))
                logging.info("listened signals: %s", str(self.listened_sig_list))



        self.pwd = "BEIjing@0603"
        self.json_path = json_path
        self.sig_updated_list = {}
        self.sig_counter = 0
        self.sig_val_counter = {}
        self.sig_val_pointer = {}
        self.rev_val_list = []

        self.next_return_sig = {}
        self.next_value_rule = ''

        self.cur_path = os.path.dirname(os.path.abspath(__file__))
        self.can_enable_path = os.path.join(self.cur_path, "../can_load/enable_socketcan.sh")
        self.dbc_load_path = os.path.join(self.cur_path, "../dbc_files")
        self.setup()

    def setup(self):
        if 'can0' not in str(os.popen('ifconfig |grep can0').readlines()):
            enable_socketcan = "sudo bash " + self.can_enable_path
            if self.pwd != "":
                os.system('echo {}|sudo -S {}'.format(self.pwd, enable_socketcan))
            else:
                pwd = getpass.getpass("Please input your password:")
                os.system('echo {}|sudo -S {}'.format(pwd, enable_socketcan))

        cfg_path = os.path.join(self.dbc_load_path, "settings.ini")
        self.settings = configparser.ConfigParser()
        self.settings.read(cfg_path, encoding="utf-8")
        can_device = str(os.popen('ifconfig  |grep can').readlines())

        if 'can0' in can_device and 'can1' not in can_device:
            self.configs = [{
                "dbc_path": os.path.join(self.dbc_load_path,self.settings.get("c385ev-can", "dbc")),
                "bus": "can0",
                "channel": self.settings.get("c385ev-can", "channel")
            }]
        if 'can1' in can_device:
            self.configs = [{
                "dbc_path":  os.path.join(self.dbc_load_path, self.settings.get("c385ev-acan", "dbc")),
                "bus": "can0",
                "channel": self.settings.get("c385ev-acan", "channel")
            }, {
                "dbc_path":  os.path.join(self.dbc_load_path,self.settings.get("c385ev-bcan", "dbc")),
                "bus": "can1",
                "channel": self.settings.get("c385ev-bcan", "channel")
            }]

        self.can_app = SocketCANApp(self.configs, 'c385ev')


    def onSignalUpdate(self, sig_name, sig_val):
        """Callback function who can monitor the signals change.
            <sig_updated_list> is a single key and multi values dict.
            <sig_val_list> could list all values for a specific signal.
            <sig_val_list[len(sig_val_list)-1]>:the last value for a specific signal.
        """

        print("{} --> {}".format(sig_name, sig_val))
        for send_group in self.send_groups:
            for name, value_rule in send_group['output_sig'].items():
                if sig_name == name and str(value_rule).startswith(str(sig_val)) and len(self.rev_val_list)==0:
                    #print("{} --> {}".format(sig_name, sig_val))
                    #self.rev_val_list.append(sig_val)
                    self.next_return_sig = send_group['return_sig']
                    self.next_value_rule = value_rule
                    break

        if len(self.next_value_rule) > 0:
            #print("222-{} --> {}".format(sig_name, sig_val))
            self.rev_val_list.append(str(sig_val))
           # print(self.rev_val_list, str(self.next_value_rule).split('-'))
            if self.rev_val_list==self.next_value_rule.split('-'):
                self.rev_val_list = []
                # self.sig_val_counter = {}
                self.can_app.setSignal('CAN', None, self.next_return_sig)
                self.next_return_sig = {}
                self.next_value_rule = ''
                self.rev_val_list = []

            if len(self.rev_val_list) > 5:
                self.next_return_sig = {}
                self.next_value_rule = ''
                self.rev_val_list = []

    def stop(self):
        self.stopped = True
        self.can_app.stop()
        self.can_app.removeListener()

    def start(self):
        self.can_app.start()
        self.stopped = False

    async def signalOperator(self):
        """Interface to send and receive specify signals.
        Add a listener if listened signal is not null.
        Go to set signal if <send_specific_sig> signal dict is not null.

        """
        self.can_app.setup()
        print("----------------------CAN Signal Information-----------------------\n")
        self.start()

        if self.listened_sig_list:
            self.can_app.addListener('CAN', None, self.listened_sig_list, self.onSignalUpdate)
            if self.pre_sigs:
                logging.info("prepare signals:%s", json.dumps(self.pre_sigs))
                self.can_app.setSignal('CAN', None, self.pre_sigs)
        while True:
            await asyncio.sleep(1)

    def begin_monitor(self):
        loop = asyncio.new_event_loop()
        asyncio.set_event_loop(loop)
        loop.run_until_complete(self.signalOperator())
        loop.close()


if __name__ == "__main__":
    a = MonitorSignal("/home/zhangaguan/code/matrix/mega_cantools_lib/mega_cantools_lib/ecu_simulator/ecu_json/c385ev_autohead.json")
    a.begin_monitor()