# -*- coding: utf-8 -*-
import os
import sys
import queue
import asyncio
import json
import configparser
from collections import OrderedDict
import getpass
global_queue = queue.Queue()
sys.path.append(os.path.dirname(os.path.abspath(__file__))+'/../../')
from mega_cantools_lib.signal_monitor.socketcan_wrapper import SocketCANApp

class MonitorSignal(object):
    """
    The :class:`MonitorSignal` object is used to send or receive CAN message.

    func:`onSignalUpdate` is the callback function who can monitor the signals
    change.

    func:`signalOperator` is a async interface to send and receive specify signals.
    The :class:`SignalSaver` can save the signal and values by listened to csv.

    """
    def __init__(self, ecu_name):
        self.ecu_name = ecu_name
        self.cur_path = os.path.dirname(os.path.abspath(__file__))
        json_name ='ecu_json/' +  self.ecu_name + '.json'
        json_path = os.path.join(self.cur_path, json_name)

        if json_path and os.path.splitext(json_path)[1] == '.json' and os.path.isfile(json_path):
            print(json_path)
            with open(json_path, 'r') as json_file:
                json_content = json_file.read()
                json_dict = json.loads(json_content, object_pairs_hook=OrderedDict)
                send_groups = json_dict['groups']

                self.listened_sig_list = []
                for send_group in send_groups:
                    for sig_name in send_group['output_sig'].keys():
                        self.listened_sig_list.append(str(sig_name))
                self.listened_sig_list = list(set(self.listened_sig_list))
                print(self.listened_sig_list)

        self.json_path = json_path
        self.sig_updated_list = {}
        self.sig_counter = 0
        self.sig_val_counter = {}
        self.sig_val_pointer = {}
        self.cur_driver_temp = 18.0
        self.cur_psn_temp = 18.0
        self.auto_st = True
        self.ac_st = True
        self.sync_st = True
        self.ion_st = True
        self.fdefrost_st = True
        self.rdefrost_st = True
        self.cir_st = 0
        self.wind_mode = 0

        self.can_enable_path = os.path.join(self.cur_path, "../can_load/enable_socketcan.sh")
        self.dbc_load_path = os.path.join(self.cur_path, "../dbc_files")

    def setup(self):
        if 'can0' not in str(os.popen('ifconfig |grep can0').readlines()):
            enable_socketcan = "sudo bash " + self.can_enable_path
            pwd = getpass.getpass("Please input your password:")
            os.system('echo {}|sudo -S {}'.format(pwd, enable_socketcan))

        cfg_path = os.path.join(self.dbc_load_path, "settings.ini")
        self.settings = configparser.ConfigParser()
        self.settings.read(cfg_path, encoding="utf-8")

        can_device = str(os.popen('ifconfig  |grep can').readlines())

        if 'can0' in can_device and 'can1' not in can_device:
            self.configs = [{
                "dbc_path": os.path.join(self.dbc_load_path, self.settings.get("can", "dbc")),
                "bus": "can0",
                "channel":self.settings.get("can", "channel")
            }]
        if 'can1' in can_device:
            self.configs = [{
                "dbc_path": os.path.join(self.dbc_load_path, self.settings.get("acan", "dbc")),
                "bus": "can0",
                "channel": self.settings.get("acan", "channel")
            }, {
                "dbc_path": os.path.join(self.dbc_load_path, self.settings.get("bcan", "dbc")),
                "bus": "can1",
                "channel": self.settings.get("bcan", "channel")
            }]

        return SocketCANApp(self.configs)

    def tempBarSetting(self, sig_name, sig_val):
        if sig_name in ('ACU_HVACFR_DrTempSetting', 'ACU_HVACF_VR_TempSetting'):
            self.can_app.setSignal('CAN', None, {'HVAC_DriverTempSelect': sig_val})
            self.cur_driver_temp = sig_val
            print("cur_dr_temp={}".format(self.cur_psn_temp))


        if sig_name in ('ACU_HVACFR_PsnTempSetting', 'ACU_HVACF_VR_PsnTempSetting'):
            self.can_app.setSignal('CAN', None, {'HVAC_PsnTempSelect': sig_val})
            self.cur_psn_temp = sig_val
            print("cur_psn_temp={}".format(self.cur_psn_temp))

    def tempSoftBtnSetting(self, sig_name,  sig_val):
        if sig_name == 'ACU_HVACF_FLTempIncBtnSt':
            if self.cur_driver_temp < 32.0:
                self.cur_driver_temp = float(self.cur_driver_temp) + 0.5
                self.can_app.setSignal('CAN', None, {'HVAC_DriverTempSelect': self.cur_driver_temp})  # 1

        if sig_name == 'ACU_HVACF_FLTempDecBtnSt':
            if self.cur_driver_temp > 18.0:
                self.cur_driver_temp = float(self.cur_driver_temp) - 0.5
                self.can_app.setSignal('CAN', None, {'HVAC_DriverTempSelect': self.cur_driver_temp})

        if sig_name == 'ACU_HVACF_FRTempIncBtnSt':
            if self.cur_psn_temp < 32.0:
                self.cur_psn_temp = float(self.cur_psn_temp) + 0.5
                self.can_app.setSignal('CAN', None, {'HVAC_PsnTempSelect': self.cur_psn_temp})

        if sig_name == 'ACU_HVACF_VR_TempChange':
            if sig_val < 0 and self.cur_driver_temp >= 20.0:
                self.cur_driver_temp = float(self.cur_psn_temp) + float(sig_val)
                self.can_app.setSignal('CAN', None, {'HVAC_DriverTempSelect': self.cur_driver_temp})
            if sig_val > 0 and self.cur_driver_temp <= 30.0:
                self.cur_driver_temp = float(self.cur_driver_temp) + float(sig_val)
                self.can_app.setSignal('CAN', None, {'HVAC_DriverTempSelect': self.cur_driver_temp})

        if sig_name == 'ACU_HVACF_VR_PsnTempChange':
            if sig_val < 0 and self.cur_psn_temp >= 20.0:
                self.cur_psn_temp = float(self.cur_psn_temp) + float(sig_val)
                self.can_app.setSignal('CAN', None, {'HVAC_PsnTempSelect': self.cur_psn_temp})
            if sig_val > 0 and self.cur_psn_temp <= 30.0:
                self.cur_psn_temp = float(self.cur_psn_temp) + float(sig_val)
                self.can_app.setSignal('CAN', None, {'HVAC_PsnTempSelect': self.cur_psn_temp})


    def contrSoftBtnSetting(self, sig_name):
        if sig_name == 'ACU_HVACF_CirBtnSt':
            self.cir_st = self.cir_st % 3 + 1
            self.can_app.setSignal('CAN', None, {'HVAC_AirCirculationSt': self.cir_st})

        if sig_name == 'ACU_HVACF_IonBtnSt' and self.ion_st:
            self.can_app.setSignal('CAN', None, {'HVAC_IonMode': 1})
            self.ion_st = False

        elif sig_name == 'ACU_HVACF_IonBtnSt' and not self.ion_st:
            self.can_app.setSignal('CAN', None, {'HVAC_IonMode': 0})
            self.ion_st = True

        if sig_name == 'ACU_HVACFR_AutoModeBtnSt' and self.auto_st:
            self.can_app.setSignal('CAN', None, {'HVAC_AutoSt': 1})
            self.auto_st = False

        elif sig_name == 'ACU_HVACFR_AutoModeBtnSt' and not self.auto_st:
            self.can_app.setSignal('CAN', None, {'HVAC_AutoSt': 0})
            self.auto_st = True

        if sig_name == 'ACU_HVACF_ACBtnSt' and self.ac_st:
            self.can_app.setSignal('CAN', None, {'HVAC_ACSt': 1})
            self.ac_st = False

        elif sig_name == 'ACU_HVACF_ACBtnSt' and not self.ac_st:
            self.can_app.setSignal('CAN', None, {'HVAC_ACSt': 0})
            self.ac_st = True

        if sig_name == 'ACU_HVACF_DualSyncBtnSt' and self.sync_st:
            self.can_app.setSignal('CAN', None, {'HVAC_DualSyncSt': 1})
            self.sync_st = False

        elif sig_name == 'ACU_HVACF_DualSyncBtnSt' and not self.sync_st:
            self.can_app.setSignal('CAN', None, {'HVAC_DualSyncSt': 0})
            self.sync_st = True

        if sig_name == 'ACU_HVACF_FDefrostBtnSt' and self.wind_mode != 5:
            self.can_app.setSignal('CAN', None, {'HVAC_WindExitMode': 5})
            self.fdefrost_st = False
            self.wind_mode = 5

        elif sig_name == 'ACU_HVACF_FDefrostBtnSt' and self.wind_mode == 5:
            self.can_app.setSignal('CAN', None, {'HVAC_WindExitMode': 0})
            self.fdefrost_st = True
            self.wind_mode = 0

        if sig_name == 'ACU_HVACF_RDefrostBtnSt' and self.rdefrost_st:
            self.can_app.setSignal('CAN', None, {'HVAC_RearDefrostSt': 1})
            self.rdefrost_st = False

        elif sig_name == 'ACU_HVACF_RDefrostBtnSt' and not self.rdefrost_st:
            self.can_app.setSignal('CAN', None, {'HVAC_RearDefrostSt': 0})
            self.rdefrost_st = True

    def windModeSetting(self, ret_sig_val):
            self.can_app.setSignal('CAN', None, ret_sig_val)
            for sig in ret_sig_val:
                self.wind_mode = ret_sig_val[sig]
                print("self.wind_mode={}".format(self.wind_mode))

    def hvacSignalUpdate(self, send_groups, sig_name, sig_val):
        for send_group in send_groups:
            for name, value in send_group['output_sig'].items():
                if sig_name == name and ',' in str(value) and str(sig_val).strip() in str(value).strip():
                    print(len(value))
                    print("{} --> {}".format(sig_name, sig_val))
                    sig_val_key = sig_name + '-' + str(sig_val)
                    if sig_val_key not in self.sig_val_counter.keys():
                        # if 'ACU_HVACF_VR_TempSetting' in sig_val_key or 'ACU_HVACF_VR_PsnTempSetting' in sig_val_key:
                        #     self.sig_val_counter[sig_val_key] = 2
                        # else:
                        self.sig_val_counter[sig_val_key] = 1
                    else:
                        self.sig_val_counter[sig_val_key] += 1

                    if sig_val_key in self.sig_val_counter.keys() and self.sig_val_counter[sig_val_key] >= 3:
                        if sig_name in ('ACU_HVACFR_DrTempSetting', 'ACU_HVACFR_PsnTempSetting',
                                        'ACU_HVACF_VR_TempSetting', 'ACU_HVACF_VR_PsnTempSetting'):
                            self.tempBarSetting(sig_name, sig_val)
                            return
                if sig_name == name and ',' not in str(value) and str(sig_val).strip() == str(value).strip():
                    print("{} --> {}".format(sig_name, sig_val))

                    sig_val_key = sig_name + '-' + str(sig_val)
                    if sig_val_key not in self.sig_val_counter.keys():
                        # if 'ACU_HVACF_ACBtnSt' in 'ACU_HVACFR_WindSpeedSetting' in sig_val_key or 'ACU_FRHVSMAutoModeCfg' in sig_val_key or 'ACU_FLHVSMAutoModeCfg' in sig_val_key \
                        #         or 'ACU_HVACF_VR_TempChange' in sig_val_key or 'ACU_HVACF_VR_PsnTempChange' in sig_val_key\
                        #         or 'ACU_HVACF_VR_HVACONOFF'  in sig_val_key or 'ACU_HVACF_VR_WindSpeedSetting' in sig_val_key:
                        #     self.sig_val_counter[sig_val_key] = 2
                        # else:
                        self.sig_val_counter[sig_val_key] = 1
                    else:
                        self.sig_val_counter[sig_val_key] += 1

                    if sig_val_key in self.sig_val_counter.keys() and self.sig_val_counter[sig_val_key] >= 3:
                        self.sig_val_counter[sig_val_key] = 0
                        self.sig_val_counter = {}
                        if sig_name in ('ACU_HVACF_FLTempIncBtnSt', 'ACU_HVACF_FLTempDecBtnSt', 'ACU_HVACF_FRTempIncBtnSt',
                                        'ACU_HVACF_FRTempDecBtnSt', 'ACU_HVACF_VR_TempChange', 'ACU_HVACF_VR_PsnTempChange'):
                            self.tempSoftBtnSetting(sig_name, sig_val)
                            return
                        if sig_name in ('ACU_HVACFR_AutoModeBtnSt', 'ACU_HVACF_ACBtnSt', 'ACU_HVACF_DualSyncBtnSt',
                                        'ACU_HVACF_IonBtnSt', 'ACU_HVACF_FDefrostBtnSt', 'ACU_HVACF_RDefrostBtnSt',
                                        'ACU_HVACF_CirBtnSt'):
                            self.contrSoftBtnSetting(sig_name)
                            return
                        if str(sig_name) == 'ACU_HVACFR_ModeSetting':
                            self.windModeSetting(send_group['return_sig'])
                            return
                        else:
                            self.can_app.setSignal('CAN', None, send_group['return_sig'])
                            return

    def progressBarSetting(self, sig_name, sig_val):
        if sig_name == 'ACU_IAL_BrightnessCfg' and int(sig_val) > 0:
            self.can_app.setSignal('CAN', None, {'IAL_BrightnessSt': sig_val})
        if sig_name == 'ACU_IAL_ColorCfg' and int(sig_val) > 0:
            self.can_app.setSignal('CAN', None, {'IAL_LampColorSt': sig_val})
        if sig_name == 'ACU_DischgSocCfg':
            self.can_app.setSignal('CAN', None, {'BMS_BattSocDisp': 95, 'VCU_DischgSocResp': sig_val})

    def carSettingsSignalUpdate(self, send_groups, sig_name, sig_val):
        for send_group in send_groups:
            for name, value in send_group['output_sig'].items():
                if sig_name == name:
                    if ',' in str(value) and str(sig_val).strip() in str(value).strip():
                        print("{} --> {}".format(sig_name, sig_val))

                        sig_val_key = sig_name + '-' + str(sig_val)
                        if sig_val_key not in self.sig_val_counter.keys():
                            self.sig_val_counter[sig_val_key] = 1
                        else:
                            self.sig_val_counter[sig_val_key] += 1

                        if sig_val_key in self.sig_val_counter.keys() and self.sig_val_counter[sig_val_key] >= 3:
                            self.sig_val_counter[sig_val_key] = 0
                            #self.sig_val_counter = {}
                            if sig_name in ('ACU_IAL_BrightnessCfg', 'ACU_IAL_ColorCfg', 'ACU_DischgSocCfg'):
                                self.progressBarSetting(sig_name, sig_val)
                                break

                    if ',' not in str(value) and str(sig_val).strip() == str(value).strip():
                        print("{} --> {}".format(sig_name, sig_val))

                        if 'return_sig' in send_group.keys():
                            sig_val_key = sig_name + '-' + str(sig_val)
                            if sig_val_key not in self.sig_val_counter.keys():
                                self.sig_val_counter[sig_val_key] = 1
                            else:
                                self.sig_val_counter[sig_val_key] += 1

                            if sig_val_key in self.sig_val_counter.keys() and self.sig_val_counter[sig_val_key] >= 3:
                                self.sig_val_counter[sig_val_key] = 0
                                #self.sig_val_counter = {}
                                self.can_app.setSignal('CAN', None, send_group['return_sig'])
                                break

    def onSignalUpdate(self, sig_name, sig_val):
        """Callback function who can monitor the signals change.
            <sig_updated_list> is a single key and multi values dict.
            <sig_val_list> could list all values for a specific signal.
            <sig_val_list[len(sig_val_list)-1]>:the last value for a specific signal.

        """

        if self.json_path and os.path.splitext(self.json_path)[1] == '.json' and os.path.isfile(self.json_path):
            with open(self.json_path, 'r') as json_file:
                json_content = json_file.read()
                json_dict = json.loads(json_content, object_pairs_hook=OrderedDict)
                send_groups = json_dict['groups']

                if self.ecu_name == 'hvac':
                    self.hvacSignalUpdate(send_groups, sig_name, sig_val)
                if self.ecu_name == 'carsettings':
                    self.carSettingsSignalUpdate(send_groups, sig_name, sig_val)

    async def signalOperator(self):
        """Interface to send and receive specify signals.
        Add a listener if listened signal is not null.
        Go to set signal if <send_specific_sig> signal dict is not null.

        """
        self.can_app = self.setup()
        print("----------------------CAN Signal Information-----------------------\n")
        if self.listened_sig_list:
            self.can_app.addListener('CAN', None, self.listened_sig_list, self.onSignalUpdate)
            if 'carsettings.json' in self.json_path: #初始化一些车控信号
                init_sig_dict = {
                    'VCU_VehDrvMod': 3,
                    'VCU_EcoPlusModeAvail': 1,
                    'BCS_HDCFuncResp': 0,
                    'VCU_WarmSt': 0,
                    'IFC_LKS_St': 2,
                    'PEPS_WELCfgSt': 1,
                    'AVAS_ACU_WelToneSt': 1,
                    'VCU_DischgSocResp': 99,
                    'BMS_BattSocDisp': 95,
                    'BCM_ParkingLampSt': 1,
                    'VCU_LongDistResp': 1
                }
                print("begin setting the init signals")
                self.can_app.setSignal('CAN', None, init_sig_dict)

        while True:
            await asyncio.sleep(1)

    def begin_monitor(self):
        loop = asyncio.new_event_loop()
        asyncio.set_event_loop(loop)
        loop.run_until_complete(self.signalOperator())
        loop.close()