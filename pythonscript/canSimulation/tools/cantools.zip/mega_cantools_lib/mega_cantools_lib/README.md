##Instruction
 ```
    mega_cantools_lib includes 4 sub-libs:
    diagnostics
    ecu_simulator
    signal_monitor
    blf
 ```
##Install
 ```
   pip install -r requirements.txt
   devpi install mega_cantools_lib
 ```
# 1. diagnostics instruction
1.1 provide the uds diag function, such as read did , write did, read dtc and etc.
detailed interface:
 ```
    enter_extendedMode()
    enter_defaultMode()
    reset_ecu()
    write_did(did, value)
    read_did(did)
    request_seeds(level)
    send_keys(level, key)
    get_dtcs()
    clear_dtc()
 ```
#RUN  
1.2 provide diag tool: did_editor.py.
 ```
       python did_editor.py -r 0xF190
       python did_editor.py -w 0xF190 LMGNMT01901000080
       python did_editor.py --dtc
       python did_editor.py --reset
 ```

# 2 signal_monitor Instruction

## Summary
* signal_monitor can send can signals to CDC periodic and update and plot can 
  signals from CDC in real time. It can locate signal channels automatically and also 
  approves monitoring and sending in specific channel.
  
 #Monitor signals no matter upper or lower:
 1. monitor one specific signal.such as:
 ```
     python monitor.py -l ACU_LDW_LKACfg
     python monitor.py -l acu_LDW_lkacfg
 ``` 
 2. monitor multiple specific signals. such as:
 ```
     python monitor.py -l ACU_LDW_LKACfg -l ACU_DrvModCfg -l ACU_PAS_ButtonPress
 ```
 outputs:
 ```
--------------------Begin to monitor signal changes---------------------

ACU_DrvModCfg --> changes to --> SPORT Mode
ACU_DrvModCfg --> SPORT Mode
ACU_DrvModCfg --> SPORT Mode
ACU_DrvModCfg --> changes to --> Invalid
ACU_DrvModCfg --> Invalid
ACU_DrvModCfg --> Invalid

ACU_LDW_LKACfg --> changes to --> Active
ACU_LDW_LKACfg --> Active
ACU_LDW_LKACfg --> Active
ACU_LDW_LKACfg --> changes to --> No command
ACU_LDW_LKACfg --> No command
ACU_LDW_LKACfg --> No command
```
 3. monitor one specific message by any one signal in this frame. such as:
  ```
     python monitor.py -lm ACU_LDW_LKACfg
 ```
 4. Generating a real-time scatter diagram when monitor signals.
 ```
     python monitor.py -l ACU_LDW_LKACfg -l ACU_DrvModCfg --plot
 ```
 
 #Sending signals no matter upper or lower:
  
 1. sending one specific signal with values . such as:
 ```
     python monitor.py -s VCU_VehDrvMod -v 1
     python monitor.py -s vcu_Vehdrvmod -v 1,2,3
 ``` 
 2. sending multiple specific signals with value in parameter order. such as:
 ```
     python monitor.py -s IFC_LKS_St -v 1 -s VCU_VehDrvMod -v 1
 ```
 3. sending functions can locate signals and channel automatically by signal receivers 
    if a signal in different dbcs with same name. Besides, specify the channel 
    was approved too. such as: 
 ```
     python monitor_signal2.py -s IFC_LKS_St -v 1 -c 1
 ```
 4. repeat sending:
 ```
     python monitor_signal2.py -s IFC_LKS_St -v 1 -r 10
 ```

# 3 ecu_simulator Instruction
 ```
    A simple GN HYCAN ECU signal simulator, just support hvac and carsettings.
    python simulator.py --ecu hvac
    python simulator.py --ecu carsettings
 ```
# 4 blf Instruction
 ```
    A mega blf record/replay tools.
    1. Record can messages  to a blf file.
    2. Plays back messages in blf file in the recorded order with an time intervals.
       it can filter can frames to play.
    3. Convert blf file to csv format.
 ```