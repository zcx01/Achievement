## -*- coding: utf-8 -*-
import os
import csv
import datetime
from dateutil.parser import parse

'''
Product:GN
Class: SignalListened
Description:collect signals/values were listened 
'''
class SignalSaver():
    def __init__(self):
        self.first_time = datetime.datetime.now().strftime('%H:%M:%S.%f')
        self.last_time_delta = 0
        self.signal_list = []

        self.file = 'signal_listened.csv'
        if os.path.exists(self.file):
            os.remove(self.file)

        if not os.path.exists(self.file):
            csvfile = open(self.file, 'w')
            writer = csv.writer(csvfile)
            writer.writerow([
                'time',
                'msenconds',
                'signal',
                'signal_copy'
            ])
            csvfile.close()

    def message_saver(self, indented_signals):
        csvfile = open(self.file, 'a+')
        writer = csv.writer(csvfile)
        now_time = datetime.datetime.now().strftime('%H:%M:%S.%f')

        time_delta1 = (parse(now_time) - parse(self.first_time)).seconds
        time_delta2 = (parse(now_time) - parse(self.first_time)).microseconds
        time_delta = format((int(time_delta1) + float(format(float(time_delta2/1000000), '.3f'))),'.3f')

        for i in range(len(indented_signals)):
            signal = indented_signals[i]
            sig_name = indented_signals[i].split(':')[0].strip()
            sig_val = indented_signals[i].split(':')[1].strip()

            signal_copy = sig_name + '\n' + sig_val

            data = [(
                now_time,
                time_delta,
                signal,
                signal_copy
            )]
            writer.writerows(data)

    def signal_saver(self, signal):
        csvfile = open(self.file, 'a+')
        writer = csv.writer(csvfile)
        now_time = datetime.datetime.now().strftime('%H:%M:%S.%f')

        time_delta1 = (parse(now_time) - parse(self.first_time)).seconds
        time_delta2 = (parse(now_time) - parse(self.first_time)).microseconds
        time_delta = format((int(time_delta1) + float(format(float(time_delta2/1000000), '.3f'))),'.3f')
        if float(time_delta) - float(self.last_time_delta) > 0.01:
            self.last_time_delta = float(time_delta)
        else:
            time_delta = float(self.last_time_delta)

        signal_copy = str(signal).split(":")[0] + '\n' + str(signal).split(":")[1]
        data = [(
            now_time,
            time_delta,
            signal,
            signal_copy
        )]
        writer.writerows(data)


class SignalValueChoices():
    def __init__(self):
        self.choices_file = 'signal_value_choices.csv'
        if os.path.exists(self.choices_file):
            os.remove(self.choices_file)

        if not os.path.exists(self.choices_file):
            csvfile = open(self.choices_file, 'w')
            writer = csv.writer(csvfile)
            writer.writerow([
                'signal',
                'value',
                'text',
                'choice',
            ])
            csvfile.close()

    def signal_value_choices_saver(self, signal, choices):
        csvfile = open(self.choices_file, 'a+')
        writer = csv.writer(csvfile)
        if choices:
            for (value, text) in choices.items():
                data = [(
                    signal,
                    value,
                    text,
                    str(signal) + ':' + str(text)
                )]
                writer.writerows(data)


