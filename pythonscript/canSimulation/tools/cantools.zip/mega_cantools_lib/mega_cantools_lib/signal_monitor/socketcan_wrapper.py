import can
from can.interfaces import socketcan
from threading import Thread
import cantools
import asyncio
import json
import time
import sys
import re
import random
from collections import namedtuple
from decimal import Decimal
SignalListenerInfo = namedtuple("SignalListenerInfo", "channel bus_type msg_id sig_name callback_func")

"""
This Listener simply prints to stdout / the terminal or a file.
"""

import logging
from can.listener import Listener
from can.io.generic import BaseIOHandler


logger = logging.getLogger('mega_cantools')


COUNT = None

class Printer(BaseIOHandler, Listener):

    def __init__(self, id_count_dic=None, file=None):

        self.id_count_dic = id_count_dic
        self.count = 0

        self.write_to_file = file is not None
        super(Printer, self).__init__(file, mode='w')

    def on_message_received(self, msg):
        if msg.arbitration_id in self.id_count_dic.keys():
            self.id_count_dic[msg.arbitration_id] += 1
            logger.debug("total: {} detail: {}".format(sum(self.id_count_dic.values()), json.dumps(self.id_count_dic)))
            global COUNT
            COUNT = self.id_count_dic
            if self.write_to_file:
                self.file.write(str(msg) + '\n')


class SocketCANApp:
    '''
    Arguments
    channel_mapping -- Dictionary  bind one dbc to the channel
        e.g. [{'dbc_path':'a.dbc', 'bus':'can0'},
              {'dbc_path':'b.dbc', 'bus':'can1'}]
    '''
    def __init__(self, bus_mappings_list, project='GN01', monkey_node=None, monkey_file = None, decode_choices=True):

        self.project = project
        self.bus_list = []
        self.tp_bus_list = []
        self.message_list = []
        self.senders_dic = {}
        self.monkey_node = monkey_node
        self.monkey_frame_id = []
        self.monkey_file = monkey_file
        self.decode_choices = decode_choices

        for bus_map in bus_mappings_list:
            if str.upper(self.project) == 'GN01':
                bus = can.interface.Bus(channel=bus_map['bus'], bustype='socketcan', bitrate=500000)
            elif str.upper(self.project) == 'C385EV' or str.upper(self.project) == 'IAT':
                bus = can.Bus(channel=bus_map['bus'], bustype='socketcan', fd=True)   # can_filters =[{"can_id": 0x1C1,"can_mask":0xFFF}]
            dbc = cantools.db.load_file(bus_map['dbc_path'])
            self.bus_list.append({'dbc_obj':dbc, 'bus_obj':bus, 'dbc_path': bus_map['dbc_path']})
            self.tp_bus_list.append(bus)

        self.task_dict = {}
        self.msg_dict = {}

        self.initialize_task_list = []
        self.initialize_msg_list = []

        self.is_msg_listened = False
        self.listenerInfoList = []
        self.task_started = False

        self.senders_dic = self.get_dbc_senders()
        self.monkey_frame_id = self.get_monkey_frame_id()
        self.monkey_frame_count = {}


    def setup(self, channel=0):
        if self.monkey_node:
            for frame_id in self.monkey_frame_id:
                self.monkey_frame_count[frame_id] = 0
            logger.info("monkey test frame id: {}".format(self.monkey_frame_count))
            self.notifier = can.Notifier(self.tp_bus_list, [Printer(id_count_dic=self.monkey_frame_count, file=self.monkey_file)])
        else:
            if channel != None:
                self.notifier = can.Notifier(self.tp_bus_list[int(channel)], [], 1.0, asyncio.get_event_loop())
            else:
                self.notifier = can.Notifier(self.tp_bus_list, [], 1.0, asyncio.get_event_loop())
        self.notifier.add_listener(self._internalCallback)

    def _initializeSignalDict(self, sig_dict, signals):
        for sig in signals:
            if sig.initial:
                sig_val = Decimal(sig.scale) * sig.initial + Decimal(sig.offset)
                sig_dict[sig.name] = sig_val
            else:
                sig_dict[sig.name] = sig.minimum

    def randomMessageProductor(self):
        if len(self.message_list) == 0:
            temp_bus_len = len(self.bus_list)
            if len(self.bus_list) == 2:
                if self.bus_list[0]['dbc_path'] == self.bus_list[1]['dbc_path']:
                    temp_bus_len = 1

            for cha in range(temp_bus_len):
                dbc = self.bus_list[cha]['dbc_obj']
                for message in dbc.messages:
                    if 'CDC' not in message.senders and 'HUD' not in message.senders and message.frame_id in self.monkey_frame_id:
                        self.message_list.append(message)

        random_message = self.message_list[random.randint(0, len(self.message_list)-1)]
        logger.debug("random message name : {}".format(random_message.name))
        return random_message

    def generate_raw_message(self, message, data):
        if str.upper(self.project) == 'GN01':
            raw_message = can.Message(arbitration_id=message.frame_id, data=data, is_extended_id=False)
        else:
            raw_message = can.Message(arbitration_id=message.frame_id, data=data, is_extended_id=False, is_fd=True, bitrate_switch=True)
        return raw_message

    def randomDataProductor(self, message):
        sig_dict = {}
        for sig in message.signals:
            sig_dict[sig.name] = self.randomValueProductor(sig)
        try:
            data = message.encode(sig_dict, strict=False)
            raw_message = self.generate_raw_message(message, data)
            logger.info(raw_message)
            return raw_message
        except:
            return ''

    def randomValueProductor(self, sig):
        if sig._is_signed:
            random_v = random.randint(-2 ** ( sig.length - 1), 2 ** ( sig.length - 1) - 1)
        else:
            random_v = random.randint(0, 2 ** sig.length - 1)
        if isinstance(sig.scale, float):
            random_value = round(Decimal(sig.scale) * random_v + Decimal(sig.offset), 2)
        else:
            random_value = sig.scale * random_v + sig.offset
        return random_value

        # if sig.scale == 1:
        #     random_value = random.randint(sig.minimum, int(sig.maximum))
        # else:
        #     min_pv = (sig.offset + sig.minimum) /sig.scale
        #     max_pv =  (sig.offset + sig.maximum) /sig.scale
        #     temp_min_pv = min_pv  #if isinstance(min_pv, int) else int(max_pv) +1
        #     random_pv = random.randint(temp_min_pv, int(max_pv))
        #     random_value = random_pv * sig.scale - sig.offset

    def initializeAllMessageDict(self):
        if not self.task_started:
             return
        logger.info("send the initial signal value periodic")
        temp_bus_len = len(self.bus_list)
        if len(self.bus_list) == 2:
            if self.bus_list[0]['dbc_path'] == self.bus_list[1]['dbc_path']:
                temp_bus_len = 1

        for cha in range(temp_bus_len):
            dbc = self.bus_list[cha]['dbc_obj']

            for message in dbc.messages:
                initialize_task_dict = {}
                initialize_msg_dict = {}
                if 'CDC' not in message.senders and 'HUD' not in message.senders and message.frame_id in self.monkey_frame_id:
                    sig_dict = {}
                    for sig in message.signals:
                        if sig.initial:
                            sig_val = Decimal(sig.scale) * sig.initial + Decimal(sig.offset)
                            sig_dict[sig.name] = sig_val
                        else:
                            sig_dict[sig.name] = sig.minimum
                    data = message.encode(sig_dict, strict=False)
                    raw_message = self.generate_raw_message(message, data)
                    logger.info(raw_message)
                    task = self.bus_list[cha]['bus_obj'].send_periodic(raw_message, message.cycle_time / 1000.0)
                    initialize_task_dict[message.name] = task
                    initialize_msg_dict[message.name] = sig_dict

                    self.initialize_task_list.append(initialize_task_dict)
                    self.initialize_msg_list.append(initialize_msg_dict)

    def messageMonkey(self, random_periodic=False):
        temp_bus_len = len(self.bus_list)
        if len(self.bus_list) == 2:
            if self.bus_list[0]['dbc_path'] == self.bus_list[1]['dbc_path']:
                temp_bus_len = 1
        for cha in range(temp_bus_len):
            initialize_task_dict = {}
            random_message = self.randomMessageProductor()
            random_raw_message = self.randomDataProductor(random_message)
            if random_periodic:
                random_cycle_time = random.randint(random_message.cycle_time * 0.5, random_message.cycle_time * 2)
                logger.info("message cycle time: {} ms, random cycle time: {} ms".format(random_message.cycle_time, random_cycle_time))
            else:
                random_cycle_time = random_message.cycle_time

            if len(random_raw_message) > 0:
                if random_message.name in self.initialize_task_list:
                    task = self.initialize_task_list[random_message.name]
                    task.stop()
                    self.initialize_task_list.pop(random_message.name)

                task = self.bus_list[cha]['bus_obj'].send_periodic(random_raw_message, random_cycle_time / 1000.0)
                initialize_task_dict[random_message.name] = task
                self.initialize_task_list.append(initialize_task_dict)
                #self.bus_list[self.channel]['bus_obj'].send_periodic(raw_message, message.cycle_time / 1000.0)

    def start(self):
        if self.task_started:
            return
        self.task_started = True

    def stopPeriodicSendSignal(self, signal_name):
        message_name = self.get_message_name_by_signal(signal_name)
        if not message_name:
            raise NameError('signal name not find in dbc')

        if message_name in self.task_dict:
            try:
                task = self.task_dict[message_name]
                task.stop()
                self.task_dict.pop(message_name)
            except:
                pass

        if len(self.initialize_task_list) >0:
            logger.debug("stop the initialize signal task")
            for initialize_task_dict in self.initialize_task_list:
                if message_name in initialize_task_dict:
                    try:
                        task = initialize_task_dict[message_name]
                        task.stop()
                        initialize_task_dict.pop(message_name)
                    except:
                        pass
                   # task.stop()

    def stop(self):
        if not self.task_started:
            return
        for cha in range(len(self.bus_list)):
            try:
                self.bus_list[cha]['bus_obj'].stop_all_periodic_tasks()
            except:
                logger.error("meet some err when stop periodic tasks!")

        self.task_dict = {}
        self.msg_dict = {}
        self.initialize_task_list = []
        self.task_started = False

    def excuteSetSignals(self, channel, sig_dict, cycleTime):
        if not self.task_started:
            return

        specific_frame_flag = False
        for signal in set(sig_dict.keys()):
            if not specific_frame_flag:
                sig_name = signal
            if '#' in signal:
                sig_name = signal
                specific_frame_flag = True
                sig_dict[sig_name.split("#")[1]] = sig_dict.pop(signal)
        #sig_name = temp_sig#next(iter(sig_dict))
        self.channel, message_name, sig_choice, dbc = self.get_more_info(sig_name, 'set', channel)
        all_sig_dict = {}
        message = dbc.get_message_by_name(message_name)
        if not message:
            return
        if message_name in self.msg_dict:
            all_sig_dict = self.msg_dict[message_name]
        else:
            self._initializeSignalDict(all_sig_dict, message.signals)

        for sig_name, sig_val in sig_dict.items():
            if ',' in str(sig_val):
                logger.info("not support multi values yet")
                self.stop()
                sys.exit(0)

            for name in message.signal_tree:
                if str.upper(name) == str.upper(sig_name):
                    sig_name = name
                    if sig_name in all_sig_dict.keys():
                        if isinstance(sig_val, str):
                            all_sig_dict[name] = int(sig_val) if type(eval(sig_val)) == int else float(sig_val)
                        else:
                            all_sig_dict[name] = sig_val

        data = message.encode(all_sig_dict, strict=False)
        raw_message = self.generate_raw_message(message, data)
        logger.info("+++++++++{}+++++++++".format(sig_dict))
        logger.debug("value choices:{}".format(json.dumps(sig_choice, ensure_ascii=False)))
        logger.debug("message name: {}".format(message_name))
        logger.debug("frame_id(x): {}".format(message.frame_id))

        logger.debug("channel: {}".format(self.channel))
        logger.debug("cycle_time: {}ms".format(message.cycle_time))
        logger.debug("bus state: {}".format(self.bus_list[self.channel]['bus_obj'].state))
        logger.info(raw_message)

        if message_name in self.task_dict:
            task = self.task_dict[message_name]
            task.modify_data(raw_message)
        else:
            if not self.task_started:
                self.task_started = True

            if cycleTime:
                if cycleTime == 'lower':
                    logger.info('send cycle rule is lower')
                    task = self.bus_list[self.channel]['bus_obj'].send_periodic(raw_message, message.cycle_time / 1000.0, message.cycle_time / 1000.0)
                    Thread(target=self.send_lower_cycle, args=(raw_message, message, 0.5)).start()
                elif cycleTime.isdigit():
                    logger.info('send cycle rule is {}ms'.format(cycleTime))
                    task = self.bus_list[self.channel]['bus_obj'].send_periodic(raw_message, int(cycleTime) / 1000.0)
                else:
                    task = self.bus_list[self.channel]['bus_obj'].send_periodic(raw_message, message.cycle_time / 1000.0)
            else:
                task = self.bus_list[self.channel]['bus_obj'].send_periodic(raw_message, message.cycle_time / 1000.0)

            self.task_dict[message_name] = task
            self.msg_dict[message_name] = all_sig_dict
        #self.bus_list[self.channel]['bus_obj'].send_periodic(raw_message, message.cycle_time / 1000.0)

    def excuteSetSignal(self, channel, sig_name, sig_val, cycleTime):
        if not self.task_started:
            return

        self.channel, message_name, sig_choice, dbc = self.get_more_info(sig_name, 'set', channel)

        sig_dict = {}
        if '#' in sig_name:
            sig_name = sig_name.split("#")[1]

        message = dbc.get_message_by_name(message_name)

        if message_name in self.msg_dict:
            sig_dict = self.msg_dict[message_name]

        else:
            self._initializeSignalDict(sig_dict, message.signals)#

        if not message:
            return

        for name in message.signal_tree:
            if str.upper(name) == str.upper(sig_name):
                sig_name = name
                sig_dict[name] = sig_val
        data = message.encode(sig_dict, strict=False)
        raw_message = self.generate_raw_message(message, data)

        logger.info("+++++++++{}:{}+++++++++".format(sig_name, sig_val))
        logger.debug("value choices:{}".format(json.dumps(sig_choice, ensure_ascii=False)))
        logger.debug("message name: {}".format(message_name))
        logger.debug("frame_id(x): {}".format(message.frame_id))
        logger.debug("channel: {}".format(self.channel))
        logger.debug("cycle_time: {}ms".format(message.cycle_time))
        logger.debug("bus state: {}".format(self.bus_list[self.channel]['bus_obj'].state))

        logger.info(raw_message)

        if message_name in self.task_dict:
            task = self.task_dict[message_name]
            task.modify_data(raw_message)
        else:
            if not self.task_started:
                self.task_started = True

            if cycleTime:
                if cycleTime == 'lower':
                    logger.info('send cycle rule is lower')
                    task = self.bus_list[self.channel]['bus_obj'].send_periodic(raw_message, message.cycle_time / 1000.0, message.cycle_time / 1000.0)
                    Thread(target=self.send_lower_cycle, args=(raw_message, message, 0.5)).start()
                elif cycleTime.isdigit():
                    logger.info('send cycle rule is {}ms'.format(cycleTime))
                    task = self.bus_list[self.channel]['bus_obj'].send_periodic(raw_message, int(cycleTime) / 1000.0)
                else:
                    task = self.bus_list[self.channel]['bus_obj'].send_periodic(raw_message, message.cycle_time / 1000.0)
            else:
                task = self.bus_list[self.channel]['bus_obj'].send_periodic(raw_message, message.cycle_time / 1000.0)
            self.task_dict[message_name] = task
            self.msg_dict[message_name] = sig_dict

    def send_lower_cycle(self, raw_message, message, delta):
        time.sleep(message.cycle_time / 1000.0)
        times = 0
        while self.task_started:
            times += 1
            self.bus_list[self.channel]['bus_obj'].send(raw_message)
            time.sleep((message.cycle_time + times * message.cycle_time * delta) / 1000.0)

    def get_message_id_by_signal(self, signal_name):
        if "#" in signal_name:
            return int(signal_name.split("#")[0],16)
        for channel in range(len(self.bus_list)):
            dbc = self.bus_list[channel]['dbc_obj']
            for message in dbc.messages:
                for sig in message.signals:
                    if str.lower(sig.name) == str.lower(signal_name):
                        return message.frame_id

    def get_message_name_by_signal(self, signal_name):
        for channel in range(len(self.bus_list)):
            dbc = self.bus_list[channel]['dbc_obj']
            for message in dbc.messages:
                for sig in message.signals:
                    if str.lower(sig.name) == str.lower(signal_name):
                        return message.name
        return None
    def groupSignalsByMessage(self, sig_dict):
        sig_dict_by_msg_id = []
        for signal in sig_dict:
            if len(sig_dict_by_msg_id) >= 1:
                need_new_dict = False
                for msg_dict in sig_dict_by_msg_id:
                    if '#' not in signal:
                        if self.get_message_id_by_signal(signal) == self.get_message_id_by_signal(next(iter(msg_dict))):
                            need_new_dict = False
                            msg_dict[signal] = sig_dict[signal]
                            break
                        else:
                            need_new_dict = True
                    else:
                        if int(signal.split("#")[0],16) == self.get_message_id_by_signal(next(iter(msg_dict))):
                            need_new_dict = False
                            msg_dict[signal] = sig_dict[signal]
                            break
                        else:
                            need_new_dict = True
                if need_new_dict:
                    sig_dict_by_msg_id.append({signal: sig_dict[signal]})
            else:
                sig_dict_by_msg_id.append({signal:sig_dict[signal]})
        return sig_dict_by_msg_id

    def setSignal(self, bus_type, channel, sigs_dict, cycleTime=None):
        sig_dict_by_msg_id = self.groupSignalsByMessage(sigs_dict)
        for sig_dict in sig_dict_by_msg_id:
            if len(sig_dict) == 1:
                for signal in sig_dict:
                    sig_val = sig_dict[signal]
                    if isinstance(sig_val, int):
                        self.excuteSetSignal(channel, signal, int(sig_val), cycleTime)
                    if isinstance(sig_val, float):
                        self.excuteSetSignal(channel, signal, float(sig_val), cycleTime)
                    # apply to input args <--signal>, split values in one sig like <-s xxx -v 1,2,3,4>
                    if isinstance(sig_val, str):
                        value_list = []
                        if ',' in str(sig_val):
                            value_list = re.split(',', sig_val)
                        else:
                            value_list.append(sig_val)
                        for value in value_list:
                            self.excuteSetSignal(channel, signal, self.get_value_type(value), cycleTime)
                            if len(value_list) > 1:
                                time.sleep(3)
                #self.excuteSetSignal(channel, sig_dict)
            if len(sig_dict) > 1:  # set 2 or more signal:value
                 self.excuteSetSignals(channel, sig_dict, cycleTime)

    def get_value_type(self, value):
        if isinstance(eval(value), int):
            return int(value)
        elif isinstance(eval(value), float):
            return float(value)

    """get all values of specific signal name"""
    def get_signal_choices(self, signal_name):
        for channel in range(len(self.bus_list)):
            dbc = self.bus_list[channel]['dbc_obj']
            for message in dbc.messages:
                for sig in message.signals:
                    if str.lower(sig.name) == str.lower(signal_name):
                        return sig.choices

    """locate the message info channnel, message name, signal value choices, and dbc etc.
        via signal name no matter in upper or lower case.
        There are two ways to locate these elements in specify.
        1. if channel was specific, only find the signal in specific channel dbc.
        2. if channel was None, locate signal in all channels one by one. 
       
    """
    def get_more_info(self, signal_name, type, channel=None):
        temp_counter = 0
        temp_message = None
        temp_sig = None

        if channel !=None and int(channel) < len(self.bus_list):
            dbc = self.bus_list[int(channel)]['dbc_obj']

            for message in dbc.messages:
                for sig in message.signals:
                    if '#' not in signal_name:
                        if str.lower(sig.name) == str.lower(signal_name):
                            if type == 'listen':
                                temp_counter += 1
                                temp_message = message
                                temp_sig = sig
                            else:
                                return int(channel), message.name, sig.choices, dbc

                    else:
                        frame_id = int(signal_name.split("#")[0], 16)
                        if str.lower(sig.name) == str.lower(signal_name.split("#")[1]) and (message.frame_id == frame_id):
                            if type == 'listen':
                                temp_counter += 1
                                temp_message = message
                                temp_sig = sig
                            else:
                                return int(channel), message.name, sig.choices, dbc

            if type == 'listen':
                if temp_counter > 1 and '#' not in signal_name:
                    logger.warning("there are {} same signals, please specific the frame id such 2D2#{}".format(temp_counter, signal_name))
                    self.stop()
                    sys.exit(0)
                #elif temp_counter == 1:
                return int(channel), temp_message.name, temp_sig.choices, dbc
            logger.warning("specify signal {} was not be found in channel {}.\n".format(signal_name, int(channel)))
            self.stop()
            sys.exit(0)

        elif channel != None and int(channel) >= len(self.bus_list):
            logger.error("channel id is out of range.\n")
            self.stop()
            sys.exit(0)
        else:
            """when set signal:
               locate the signals info by filter the signal receiver(only TGW) besides signal name.
               when listen signal:
                locate the signals info just by signal name from channels dbc.
            
            """
            for cha in range(len(self.bus_list)):
                dbc = self.bus_list[cha]['dbc_obj']
                for message in dbc.messages:
                    for sig in message.signals:
                        if '#' not in signal_name:
                            if str.lower(sig.name) == str.lower(signal_name):
                                if type == 'listen':
                                    temp_counter += 1
                                    temp_message = message
                                    temp_sig = sig
                                else:
                                    return cha, message.name, sig.choices, dbc

                        else:
                            frame_id = int(signal_name.split("#")[0], 16)
                            if str.lower(sig.name) == str.lower(signal_name.split("#")[1]) and (
                                    message.frame_id == frame_id):
                                if type == 'listen':
                                    temp_counter += 1
                                    temp_message = message
                                    temp_sig = sig
                                else:
                                    return  cha, message.name, sig.choices, dbc
                if type == 'listen':
                    if temp_counter > 1:
                        logger.warning("there are {} same signals in channel {} dbc, please listen other signal in same frame by lm command!".format(temp_counter,cha))
                        self.stop()
                        sys.exit(0)
                    elif temp_counter == 1:
                        return cha, temp_message.name, temp_sig.choices, dbc

            if cha == len(self.bus_list) - 1:
                logger.warning("Warning: specify signal was not be found in all channel dbc.\n")
                self.stop()
                sys.exit(0)

    """get the sibling signals in same message frame """
    def get_sibling_signals(self, signal_name, channel):
            self.channel, message_name, _, dbc = self.get_more_info(signal_name, 'listen', channel)
            message = dbc.get_message_by_name(message_name)
            return message.signal_tree

    def addMsgListener(self, bus_type, channel, sig_name, callback_func):
        self.channel, message_name, _, dbc = self.get_more_info(sig_name, 'listen', channel)
        msg = dbc.get_message_by_name(message_name)
        if '#' in sig_name:
            sig_name = sig_name.split("#")[1]

        for name in msg.signal_tree:
            if str.upper(name) == str.upper(sig_name):
                sig_name = name
        logger.info("{}_{}_{}_channel:{}\n".format(sig_name, msg.frame_id, msg, self.channel))
        listener_inst = SignalListenerInfo(self.channel, bus_type, msg.frame_id, sig_name, callback_func)
        self.listenerInfoList.append(listener_inst)

        logger.info("--------------------Begin to monitor message changes---------------------\n")
        self.is_msg_listened = True
        return len(self.listenerInfoList) - 1

    def addListener(self, bus_type, channel, sig_list, callback_func):
        for sig_name in sig_list:
            self.channel, message_name, _, dbc = self.get_more_info(sig_name, 'listen',  channel)
            if '#' in sig_name:
                sig_name = sig_name.split("#")[1]

            msg = dbc.get_message_by_name(message_name)
            for name in msg.signal_tree:
                if str.upper(name) == str.upper(sig_name):
                    sig_name = name
            logger.info("{}_{}_{}_channel:{}\n".format(sig_name, msg.frame_id, msg, self.channel))
            listener_inst = SignalListenerInfo(self.channel, bus_type, msg.frame_id, sig_name, callback_func)
            self.listenerInfoList.append(listener_inst)
        logger.info("--------------------Begin to monitor signal changes---------------------\n")
        return len(self.listenerInfoList) - 1

    def removeListener(self):
        if  self.task_started:
            self.listenerInfoList.clear()
            self.notifier.stop()

        if self.monkey_node:
            logger.info("Monkey frame data file: {}".format(self.monkey_file))

            logger.info("Count Monkey frame data: Total: {}, Detail: {}".format(sum(COUNT.values()), COUNT))

    def _internalCallback(self, msg):
        for listenInfo in self.listenerInfoList:
            if msg.arbitration_id == listenInfo.msg_id:
                dbc = self.bus_list[listenInfo.channel]['dbc_obj']
                sig_dict = dbc.decode_message(msg.arbitration_id, msg.data, decode_choices = self.decode_choices)
                if not self.is_msg_listened:
                    if listenInfo.sig_name in sig_dict:
                        listenInfo.callback_func(listenInfo.sig_name, sig_dict[listenInfo.sig_name])
                if self.is_msg_listened:
                    info = self._format_signals(dbc.get_message_by_frame_id(msg.arbitration_id), sig_dict)
                    listenInfo.callback_func(info)

    def get_dbc_senders(self):
        dbc = self.bus_list[0]['dbc_obj']
        for message in dbc.messages:
            for sender in message.senders:
                self.senders_dic.setdefault(sender, []).append(message.frame_id)
        return self.senders_dic

    def get_monkey_frame_total(self):
        return COUNT
    def get_monkey_frame_id(self):
        dbc = self.bus_list[0]['dbc_obj']
        monkey_frame_id = []
        if not self.monkey_node:
            for message in dbc.messages:
                monkey_frame_id.append(message.frame_id)
        else:
            for node in self.monkey_node:
                monkey_frame_id += self.senders_dic[node]
        return monkey_frame_id

    def _format_signals(self, message, decoded_signals):
        formatted_signals = []
        for signal in message.signals:
            try:
                value = decoded_signals[signal.name]
            except KeyError:
                continue

            signal_name = signal.name

            formatted_signals.append('{}: {}'.format(signal_name, value))
        return formatted_signals

    def shutdown(self):
        self.notifier.stop()
        for bus_el in self.bus_list:
            bus_el['bus_obj'].shutdown()