# -*- coding: utf-8 -*-
import matplotlib.pyplot as plt
import pandas as pd
from matplotlib.pyplot import MultipleLocator
import csv

path = 'signal_listened.csv'
path_choice = 'signal_value_choices.csv'

def beginDraw():

  data = pd.read_csv(path, encoding='gbk')
  data = data.sort_values(by='signal', ascending=False)

  xdata = data.loc[:, 'msenconds'].tolist()
  ydata = data.loc[:, 'signal_copy'].tolist()

  with open(path_choice, 'r', encoding="utf-8") as csvfile:
    reader = csv.reader(csvfile)
    y_column = [row[3] for row in reader]
    print(len(y_column))
    print(y_column)
  # 设置输出的图片大小
  figsize = 19, 10.5
  figure, ax = plt.subplots(figsize=figsize)

  plt.scatter(xdata, ydata, marker='|', color="r")
  #元素设置
  plt.title(
      "Signal Sequence Chart\n",
      fontdict={
          'weight': 'normal',
          'name': 'Times New Roman',
          'size': 20
      })
  # 设置刻度的文字颜色/大小/字体
  for label in ax.yaxis.get_ticklabels():
    print(label.get_label())
    label.set_rotation(0)
    label.set_fontsize(12)
    label.set_fontname('Times New Roman')
  ax.locator_params(nbins=20)

  plt.tight_layout()
  plt.grid()
  plt.xlabel(
      'time(s)',
      fontdict={
          'weight': 'normal',
          'name': 'Times New Roman',
          'size': 16
      })
  plt.ylabel(
      'signal',
      fontdict={
          'weight': 'normal',
          'name': 'Times New Roman',
          'size': 16
      })
  x_major_locator = MultipleLocator(0.5)
  ax.xaxis.set_major_locator(x_major_locator)


def plot():
  plt.ion()
  plt.figure(1)
  plt.clf()
  while True:
    plt.clf()
    data = pd.read_csv(path, encoding='gbk')
    data = data.sort_values(by='signal', ascending=False)

    xdata = data.loc[:, 'msenconds'].tolist()
    ydata = data.loc[:, 'signal_copy'].tolist()

    plt.scatter(xdata, ydata, marker='|', color="r")
    plt.tight_layout()
    plt.grid()
    plt.xlabel(
        'time(s)',
        fontdict={
            'weight': 'normal',
            'size': 16
        })
    plt.ylabel(
        'signal',
        fontdict={
            'weight': 'normal',
            'size': 16
        })
    plt.pause(0.1)  # 暂停一秒
    plt.ioff()  # 关闭画图的窗口


def save():
  plt.close()
