# -*- coding: utf-8 -*-
import sys
import os
import queue
import asyncio
import time
import logging
import threading
import getpass
import configparser
global_queue = queue.Queue()
sys.path.append(os.path.dirname(os.path.abspath(__file__))+'/../../')
from mega_cantools_lib.signal_monitor.socketcan_wrapper import SocketCANApp
logger = logging.getLogger('mega_cantools')
logging.basicConfig(level='INFO', format='[%(created)f %(levelname)s] %(message)s')

class SignalMonkey():
    """
    The :class:`MonitorSignal` object is used to send or receive CAN message.

    func:`onSignalUpdate` is the callback function who can monitor the signals
    change.

    func:`signalOperator` is a async interface to send and receive specify signals.
    The :class:`SignalSaver` can save the signal and values by listened to csv.
    project="GN01"/"C385EV"

    """

    def __init__(self, pwd="", project="c385ev", channel=0, dbc = None,  random_value= False, random_periodic = False, test_time=360, monkey_node=['VCU', 'GW'], monkey_file=None):
        """
        :param pwd: sudo password
        :param project: project name
        :param channel: defalut 0
        :param dbc: specific dbc path
        :param random_value: default False:generate init value For frameId.  True: generate random values for FrameId.
        :param random_periodic: default False: static cycle time for every frameId. True: random cycle time(between static-cycle * 0.5 and static-cycle*2)
        :param test_time: specify test seconds. default:360
        :param monkey_node: specify simulate network Node. default: ['VCU','GW']
        :param monkey_file: To save sending can data to specific file path. default: None
        """
        self.project = project
        self.pwd=pwd
        self.channel = channel
        self.type = type
        if random_value == 'random':
            random_value = True
        elif random_value == 'init':
            random_value = False
        self.random_value = random_value
        self.random_periodic = random_periodic
        self.monkey_node = monkey_node
        self.test_time = test_time
        self.monkey_file = monkey_file

        if dbc:
            self.dbc = dbc
            print("dbc path is {}".format(self.dbc))
        else:
            self.dbc = ''

        self.cur_path = os.path.dirname(os.path.abspath(__file__))
        self.can_enable_path = os.path.join(self.cur_path, "../can_load/enable_socketcan.sh")
        self.dbc_load_path = os.path.join(self.cur_path, "../dbc_files")
        self.stopped = False
        self.setup()

    def setup(self):
        can_device = str(os.popen('ifconfig |grep can').readlines())
        if 'can0' not in can_device:
            enable_socketcan = "sudo bash " + self.can_enable_path
            if self.pwd != "":
                os.system('echo {}|sudo -S {}'.format(self.pwd, enable_socketcan))
            else:
                pwd = getpass.getpass("Please input your password:")
                os.system('echo {}|sudo -S {}'.format(pwd, enable_socketcan))

        cfg_path = os.path.join(self.dbc_load_path, "settings.ini")
        self.settings = configparser.ConfigParser()
        self.settings.read(cfg_path, encoding="utf-8")

        if 'can0' in can_device and 'can1' not in can_device:
            self.configs = [{
                "dbc_path": self.dbc if len(self.dbc) > 0 else os.path.join(self.dbc_load_path, self.settings.get(
                    str.lower(self.project) + "-can", "dbc")),
                "bus": "can0",
                "channel": self.settings.get(str.lower(self.project) + "-can", "channel")
            }]
        else:
            self.configs = [{
                "dbc_path": self.dbc if len(self.dbc) > 0 else os.path.join(self.dbc_load_path, self.settings.get(
                    str.lower(self.project) + "-acan", "dbc")),
                "bus": "can0",
                "channel": self.settings.get(str.lower(self.project) + "-acan", "channel")
            }, {
                "dbc_path": self.dbc if len(self.dbc) > 0 else os.path.join(self.dbc_load_path, self.settings.get(
                    str.lower(self.project) + "-bcan", "dbc")),
                "bus": "can1",
                "channel": self.settings.get(str.lower(self.project) + "-bcan", "channel")
            }]
        self.can_app = SocketCANApp(self.configs, project=self.project, monkey_node = self.monkey_node, monkey_file = self.monkey_file)


    def stop(self):
        self.stopped = True
        self.can_app.stop()
        time.sleep(1)
        self.can_app.removeListener()

    def start(self):
        self.can_app.start()
        self.stopped = False

    def get_all_node(self):
        print("Node:",list(self.can_app.get_dbc_senders().keys()))
        print("Detail:", self.can_app.get_dbc_senders())
        return self.can_app.get_dbc_senders().keys()

    def get_frame_counts(self):
        if self.monkey_node:
            temp_dic = self.can_app.get_monkey_frame_total()
            total_dic = {}
            for key,value in temp_dic.items():
                total_dic[hex(key)] = value
            print("---------------------------------------------------")
            print("Total:", sum(total_dic.values()))
            print("Detail:", total_dic)
            print("---------------------------------------------------")
            return total_dic
        else:
            print("will not count frame since no specific monkey node")
            return 0

    async def send_monkey_frame(self):
        self.start()
        st = time.time()
        if not self.random_value:
            print("----------------------begin sending init can frames----------------------\n")
            self.can_app.initializeAllMessageDict()
            while not self.stopped:
                await asyncio.sleep(1)
                if time.time() - st > self.test_time:
                    self.stop()

        if self.random_value:
            print("----------------------begin sending random can frames-----------------------\n")
            self.can_app.initializeAllMessageDict()
            while not self.stopped:
                await asyncio.sleep(0.1)
                self.can_app.messageMonkey(self.random_periodic)
                if time.time() - st > self.test_time:
                    self.stop()

        print("------------------stopped sending monkey frame------------------")

    def monkey_test(self):
        self.can_app.setup(self.channel)
        loop = asyncio.new_event_loop()
        asyncio.set_event_loop(loop)
        loop.run_until_complete(self.send_monkey_frame())
        loop.close()

if __name__ == '__main__':
    monkey = SignalMonkey(pwd="BEIjing@0603", random_value = False, random_periodic=False, test_time=20, monkey_node=['VCU','GW'], monkey_file=None)
    monkey.monkey_test()
    count_dic = monkey.get_frame_counts