if ifconfig -a |grep can0
then
   sudo ip link set can0 down
fi
if ifconfig -a |grep can1
then
   sudo ip link set can1 down
fi
if ifconfig -a |grep can2
then
   sudo ip link set can2 down
fi
if ifconfig -a |grep can3
then
   sudo ip link set can3 down
fi