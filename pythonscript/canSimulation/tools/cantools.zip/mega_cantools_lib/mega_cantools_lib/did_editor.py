# -*- coding: utf-8 -*-

"""
A mega diagnostics tools for CDC and TGW.
1. read/write did.
2. read/clear dtc.
3. ecu hard reset
"""

import os
import time
import argparse
from diagnostics.diag_wrapper import Diag_wrapper

def restore_factory_mode():
    os.system('bash mega_tools/init_mega_tool.sh')
    time.sleep(1)
    os.system('bash mega_tools/restory_factory_mode.sh')

if __name__ == '__main__':
    parser = argparse.ArgumentParser(
        description='The diagnostics tools for CDC and TGW. '
                    '1. read/write did. 2. read/clear dtc. 3. ecu hard reset')

    parser.add_argument('--ecu', metavar="ecu_name",
                        help='which ecu (TGW or CDC) to diag, default:CDC',
                        default='CDC')

    parser.add_argument('-r', '--read', metavar="did_name",
                        help='read specific did. format: --read 0x0100')

    parser.add_argument('-w', '--write', nargs=2, metavar=('did_name', 'did_value'),
                        help='write specific did for specific value. '
                             'format: --write 0x0100 FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF')

    parser.add_argument('--dtc', help='get dtc', action='store_true')

    parser.add_argument('--clear', help='clear dtc', action='store_true')

    parser.add_argument('--reset', help='ECU hard reset', action='store_true')

    parser.add_argument('-c','--channel', help='specific can channel', default='can0')


    args = parser.parse_args()
    diag_app = Diag_wrapper(args.ecu, args.channel)

    if args.read:
        resp = diag_app.read_did(args.read)
        print(resp)

    if args.write:
        if int(args.write[0], 16) == 0x0110 and args.write[1] == 'FF':
            restore_factory_mode()
        else:
            resp = diag_app.write_did(args.write)
            print(resp)

    if args.dtc:
        dtc_list = diag_app.get_dtc()
        if isinstance(dtc_list, list):
            for dtc in dtc_list:
                print (hex(dtc.id),
                       '0x{:02x}'.format(dtc.status.get_byte_as_int()),
                       '0x{:02x}'.format(dtc.severity.get_byte_as_int()))

    if args.clear:
        diag_app.clear_ttc()

    if args.reset:
        resp = diag_app.reset_ecu()
        print(resp)
