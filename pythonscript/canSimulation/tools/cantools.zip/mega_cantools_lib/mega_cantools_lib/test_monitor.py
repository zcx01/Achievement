# -*- coding: utf-8 -*-
"""
A can signal monitor tool.
1. send can signals to CDC periodic.
2. listened signals/message changes.
3. plot signal changing in real-time
"""

import argparse
from mega_cantools_lib.parsers.monitor import _monitor


def main():
    parser = argparse.ArgumentParser(
        description=' <MonitorSignal> object is used to send or receive CAN message.'
                    'it can send can signals to CDC periodic, or monitor specify signal changes.'
                    'please refer to README.md for detail')

    parser.add_argument('-j', '--json',
                        help='specific the simulator json path',
                        default=None)

    parser.add_argument('-p', '--project',
                        help='specify project, approve gn01/c385ev/IAT, default is c385ev',
                        default='c385ev')

    parser.add_argument('-c', '--channel',
                        type=int,
                        help='specify can channel',
                        default=0)

    parser.add_argument('--dbc',
                        help='specify dbc path',
                        default=None)

    parser.add_argument('--cycletime',
                        help='approve linear reduction (lower) or specific cycleTime(example 100/200) when sending',
                        default=None)
    parser.add_argument('-s', '--signal', help='specify can signal name')
    parser.add_argument('-v', '--value',
                        help="specify signal value which should follow closely <--signal>, "
                             "please only use ',' to separate multiple values. "
                             "format: -s SIGNAL -v 1,2,3; -s SIG1 -v 1 -s SIG2 -v 2")

    parser.add_argument('-r', '--repeat',
                        type=int,
                        help='specify repeat times for sending signal',
                        default=1)

    parser.add_argument('-l', '--listen',
                        help='specify signal name will be listened, please use space to '
                             'separate multiple signals like -l SIG1 -l SIG2 -l SIG3'
                        )

    parser.add_argument('-lm', '--message',
                        dest='sig_name',
                        help='monitor one message by specific any one signal in this frame')

    parser.add_argument('--plot',
                        help='Generating the scatter diagram when monitoring signals',
                        action='store_true',
                        default=None)

    parser.add_argument('-d', '--decode',
                        help='decode listened signal values (such as decode 0->OFF):default True',
                        default=True)

    parser.add_argument('--ignore',
                        help='donot send init value when sending specific signal',
                        action='store_true',
                        default=False)


    args = parser.parse_args()
    _monitor(args)