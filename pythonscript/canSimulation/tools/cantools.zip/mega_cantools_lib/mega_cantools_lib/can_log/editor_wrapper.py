# coding: utf-8
"""
blf_editor.py
1. Record can messages receiced by PCAN to a blf file.
2. Plays back messages in blf file in the recorded order with an time intervals.
   it can filter can frames to play.

"""
import os
import can
import datetime
from can.interfaces import socketcan
import sys
import getpass

'''
class:`MessageSync` which plays back messages
in the recorded order an time intervals.
'''

class MessageSync(object):
    """
    Used to iterate over some given messages in the recorded time.
    """

    def __init__(self,
                 messages,
                 frame_id_list,
                 timestamps=True,
                 gap=0.0001,
                 skip=60):
        """Creates an new **MessageSync** instance.

        :param messages: An iterable of :class:`can.Message` instances.
        :param bool timestamps: Use the messages' timestamps.
        :param float gap: Minimum time between sent messages in seconds
        :param float skip: Skip periods of inactivity greater than this (in seconds).
        """
        self.raw_messages = messages
        self.timestamps = timestamps
        self.gap = gap
        self.skip = skip
        self.frame_id_list = frame_id_list

    def __iter__(self):
        playback_start_time = time.time()
        recorded_start_time = None

        for m in self.raw_messages:
            if self.frame_id_list and str(m.arbitration_id) not in self.frame_id_list:
                continue

            if recorded_start_time is None:
                recorded_start_time = m.timestamp

            if self.timestamps:
                # Work out the correct wait time
                now = time.time()
                current_offset = now - playback_start_time
                recorded_offset_from_start = m.timestamp - recorded_start_time
                remaining_gap = recorded_offset_from_start - current_offset

                sleep_period = max(self.gap, min(self.skip, remaining_gap))
                #print("sleep={}".format(sleep_period))
            else:
                sleep_period = self.gap

            time.sleep(sleep_period)

            yield m

class PcanConfig(object):
    def __init__(self, bus, dbc, channel):
        self.bus = bus
        self.dbc = dbc
        self.channel = channel

class CanLogWrapper(object):
    def __init__(self, channel = 0, busType = 'can', pwd = ''):
        self.busType = busType
        self.channel = int(channel)
        self.pwd = pwd
        self.stopped = False

        self.cur_path = os.path.dirname(os.path.abspath(__file__))
        self.can_enable_path = os.path.join(self.cur_path, "../can_load/enable_socketcan.sh")
        self.can_disable_path = os.path.join(self.cur_path, "../can_load/disable_socketcan.sh")

        self.dbc_load_path = os.path.join(self.cur_path, "../dbc_files")
        self.setup()

    def teardown(self):
        self.bus.shutdown()

    def setup(self):
        can_device = str(os.popen('ifconfig |grep can').readlines())
        if 'can0' not in can_device:
            enable_socketcan = "sudo bash " + self.can_enable_path
            if self.pwd != "":
                os.system('echo {}|sudo -S {}'.format(self.pwd, enable_socketcan))
            else:
                pwd = getpass.getpass("Please input your password:")
                os.system('echo {}|sudo -S {}'.format(pwd, enable_socketcan))

        if str.upper(self.busType) == 'CAN':
            self.bus = can.interface.Bus(channel= 'can' + str(self.channel), bustype='socketcan', bitrate=500000)
        elif str.upper(self.busType) == 'CANFD':
            self.bus = socketcan.SocketcanBus(channel= 'can' + str(self.channel), fd=True)  # "BusType" "CAN FD";   "CANFD_BRS" "1";
        else:
            raise  TypeError("unsupported bus type {}".format(self.busType))
        return self.bus

    def blf2csv(self, blf_file, filter_ids):
        blf_file = os.path.join(self.cur_path, blf_file)
        if not os.path.exists(blf_file):
            print("The blf file is not exists.")
            sys.exit()
        print("begin convert {} into output.csv!\n".format(blf_file))
        can_log = can.BLFReader(blf_file)
        log_output = []
        for msg in can_log:
            if filter_ids and str(msg.arbitration_id) not in filter_ids:
                continue
            print(msg)
            log_output.append([msg.timestamp, hex(msg.arbitration_id), msg.dlc, ' '.join('{:02x}'.format(x) for x in msg.data), msg.channel])

        return log_output

    def record(self, duration = 600, path = os.path.dirname(os.path.abspath(__file__))):
        #self.setup()
        start_time = time.time()
        blf_name = os.path.join(path, "can_log_" + datetime.datetime.now().strftime("%Y%m%d%H%M%S") + '.blf')
        blfwriter = can.BLFWriter(blf_name)
        time.sleep(0.1)

        try:
            updated = False
            while True:
                if time.time() - start_time > int(duration):
                    blfwriter.stop()
                    start_time = time.time()
                    blf_name = os.path.join(path, "can_log_" + datetime.datetime.now().strftime("%Y%m%d%H%M%S") + '.blf')
                    blfwriter = can.BLFWriter(blf_name)

                raw_message = self.bus.recv(0.5)
                if raw_message is not None:
                    blfwriter.on_message_received(raw_message)
                    print(raw_message)

                # if 'can0' in self.can_device and 'can1' not in self.can_device:
                #     raw_message = self.bus_list[0].bus.recv(0.5)
                #     if raw_message is not None:
                #         blfwriter.on_message_received(raw_message)
                #         print(raw_message)
                # if 'can1' in self.can_device:
                #     if not updated:
                #         can0_msg = self.bus_list[0].bus.recv(1)
                #         can1_msg = self.bus_list[1].bus.recv(1)
                #         print(can1_msg)
                #         if can0_msg and can1_msg:
                #             can0_msg_time = can0_msg.timestamp
                #             can1_msg_time = can1_msg.timestamp
                #             updated = True
                #         else:
                #             print("please check the CAN Lines")
                #             return
                #     if updated and can0_msg_time < can1_msg_time:
                #         blfwriter.on_message_received(can0_msg)
                #         print(can0_msg)
                #         can0_msg = self.bus_list[0].bus.recv()
                #         can0_msg_time = can0_msg.timestamp if can0_msg is not None else None
                #         continue
                #     elif updated and can0_msg_time >= can1_msg_time:
                #         blfwriter.on_message_received(can1_msg)
                #         print(can1_msg)
                #         can1_msg = self.bus_list[1].bus.recv()
                #         can1_msg_time = can1_msg.timestamp if can1_msg is not None else None
                #         continue

        except KeyboardInterrupt:
            blfwriter.stop()
            print("record was Interrupted by Keyboard")

        finally:
            print("record finish")
            blfwriter.stop()
            self.teardown()

    def _logReader(self,filename):
        if filename.endswith(".asc"):
            can_log = can.ASCReader(filename)
        elif filename.endswith(".blf"):
            can_log = can.BLFReader(filename)
        elif filename.endswith(".csv"):
            can_log = can.CSVReader(filename)
        elif filename.endswith(".db"):
            can_log = can.SqliteReader(filename)
        elif filename.endswith(".log"):
            can_log = can.CanutilsLogReader(filename)
        else:
            raise NotImplementedError("No read support for this log format: {}".format(filename))
        return can_log

    def stop(self):
        self.stopped = True
        self.teardown()


    def _play_file(self,filepath, recycle = False, gaps = 0, filter_ids = None, verbosity = False):
        print("-----------param info-----------\nfilePath: {}\nrecycle: {} \nchannel: can{}"
              "\nfilter_ids: {} \nverbosity: {}\n-------------------------------".format(filepath, recycle,
                                                                                         self.channel, filter_ids,
                                                                                         verbosity))

        round = 1
        while True:
            print('Play Round: {}'.format(round))
            round += 1
            can_log = self._logReader(filepath)
            in_sync = MessageSync(can_log, frame_id_list=filter_ids, timestamps=True, gap=float(gaps))
            for raw_message in in_sync:
                if raw_message.is_error_frame:
                    print("11111")
                    continue
                # if raw_message.is_rx:
                #     print("RX+", raw_message)
                # else:
                #     print("TX+", raw_message)
                if verbosity:
                    print(raw_message)
                if not self.stopped:
                    self.bus.send(raw_message, timeout=0.5)
                else:
                    break
            if not recycle:
                break
            if self.stopped:
                break

    def play(self, filepath, recycle = True, gaps = 0, filter_ids = None, verbosity = False):
        """
        :param filepath: can log file path.
        :param recycle: play recycle or not.
        :param gaps: minimum time between replayed frames
        :param filter_ids: filter the can frames(decimalism) to replay
        :param verbosity: show raw message if True.
        :return:
        """


        #self.setup()
        # print("-----------param info-----------\nfilePath: {}\nrecycle: {} \nchannel: can{}"
        #       "\nfilter_ids: {} \nverbosity: {}\n-------------------------------".format(filepath, recycle, self.channel,filter_ids, verbosity))
        # #blf_file = os.path.join(self.cur_path, blf_file)
        if not os.path.exists(filepath):
            print("The canlog file is not exists.")
            return
        try:
            if str(recycle).upper() == 'FALSE':
                recycle = False

            if os.path.isdir(filepath):
                for root, dirs, files in os.walk(filepath):
                    files.sort()
                    while True:
                        for file in files:
                            blf_path = os.path.join(root, file)
                            print("begin to play {}".format(blf_path))
                            self._play_file(blf_path, recycle=False, filter_ids=filter_ids, verbosity=verbosity)
                            if not recycle:
                                break
                            if self.stopped:
                                break

            elif os.path.isfile(filepath):
                print('Can Log Playing Started on {}'.format(datetime.datetime.now()))
                self._play_file(filepath, recycle=recycle, filter_ids=filter_ids, verbosity=verbosity)

        except KeyboardInterrupt:
            pass
        finally:
            print('Can Log Playing Stopped on {}'.format(datetime.datetime.now()))
            self.teardown()


from threading import Thread
import time
if __name__ == '__main__':
    can_app = CanLogWrapper(pwd='BEIjing@0603', busType='CANFD', channel=0)
    my_dict = {'recycle': True, 'verbosity':False} #/home/zhangaguan/code/tools/mega_cantools_lib/mega_cantools_lib/a.blf
    blf_path = '/home/zhangaguan/can_log_20210713141437.blf'#  '/home/zhangaguan/code/tools/mega_cantools_lib/mega_cantools_lib/can_log_20210726150633.blf'#
    #blf_forder = '/home/zhangaguan/canlog_20210713/gn'
    #Thread(target=can_app.play, args = (blf_path,), kwargs=my_dict).start()
    can_app.play(blf_path, recycle=True, verbosity=False)

    # blf_forder = '/home/zhangaguan/canlog_20210713/gn'
    # for root, dirs, files in os.walk(blf_forder):
    #     #print(root)  # 当前目录路径
    #     #print(dirs)  # 当前路径下所有子目录
    #     #print(files)  # 当前路径下所有非目录子文件
    #     files.sort()
    #
    #     for file in files:
    #         blf_path = os.path.join(root, file)
    #         print(blf_path)
    #         can_app.play(blf_path, recycle = False, verbosity=False)
    #.
    # can_app.record(duration = 60)

    #time.sleep(10)
    #can_app.stop()