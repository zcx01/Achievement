# -*- coding: utf-8 -*-
"""
A lin signal monitor tool.
1. send lin signals to bus.
2. listened signals/message changes.
"""

import os
import sys
import argparse
from collections import OrderedDict
from mega_lintools_lib.PLinApp import PLinApp


if __name__ == "__main__":
    parser = argparse.ArgumentParser(
        description=' A tool for sending or receiving LIN signals by PCAN-USB Pro FD')

    parser.add_argument('-c', '--channel', help='specify lin channel', default=0)
    parser.add_argument('-f', '--file', help='specify LIN Description File(LDF)', default="CDC_GN01_LIN_5_01.ldf")

    parser.add_argument('-s', '--signal', help='specify lin signal name')

    parser.add_argument('-v', '--value',
                        help="specify signal value which should follow closely <--signal>")

    parser.add_argument('-r', '--repeat',
                        help='specify repeat times for sending signal. r = 5, will send 1s', default=1)

    parser.add_argument('-l', '--listen',
                        help='specify signal name will be listened')
    args = parser.parse_args()
    sig_dict = OrderedDict()

    for i in range(len(sys.argv)):
        if sys.argv[i] in ('-s' , '--signal') and sys.argv[i + 2] in ('-v' , '--value'):
            sig_dict[sys.argv[i + 1]] = int(sys.argv[i + 3])

    if not os.path.exists(args.file):
        raise KeyError("LIN Description File(LDF) not be found!")
    else:
        lin_app = PLinApp(args.file)

    if args.signal:
        lin_app.setSignals(sig_dict, int(args.repeat), channel=args.channel)

    if args.listen:
        lin_app.listenSignals(args.listen, channel=args.channel)


