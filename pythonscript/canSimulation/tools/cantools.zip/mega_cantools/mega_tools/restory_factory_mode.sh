adb -s mega0123456789  push mega_tools/mega_test_l  /flash/mega/mega_test
adb -s mega0123456789  shell chmod +x /flash/mega/mega_test
adb -s 1234567890123 push mega_tools/mega_test_a  /data/mega/mega_test
adb -s 1234567890123  shell chmod +x  /data/mega/mega_test

adb -s mega0123456789 shell  /flash/mega/mega_test write_cfg 0110 FF
adb -s 1234567890123 shell /data/mega/mega_test write_cfg 0110 FF
