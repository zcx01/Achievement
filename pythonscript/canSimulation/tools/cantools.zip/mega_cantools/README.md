#mega_cantools 使用说明
##mega_cantools包含如下工具：
```
    can信号接收/发送工具--monitor.py
    lin信号接收/发送工具--linmonitor.py
    车控/空调app的信号模拟器--simulator.py
    CDC/TGW诊断工具--did_editor.py 
    can报文录制/回放工具--blf_editor.py
```

##1.monitor.py （-p 可以指定项目, 默认为c385ev）
1.1 监听gn项目上单个/多个can信号(支持大小写)：
使用方法：
```
     python monitor.py -l ACU_LDW_LKACfg -p gn01
     python monitor.py -l acu_ldw_lkacfg -l ACU_DrvModCfg -l ACU_PAS_ButtonPress -p gn01
 ``` 
输出：
 ```
--------------------Begin to monitor signal changes---------------------

ACU_DrvModCfg --> changes to --> SPORT Mode
ACU_DrvModCfg --> SPORT Mode
ACU_DrvModCfg --> SPORT Mode
ACU_DrvModCfg --> changes to --> Invalid
ACU_DrvModCfg --> Invalid
ACU_DrvModCfg --> Invalid
```
1.2 监听message(输入message下的任一信号名)：
 ```
     python monitor.py -lm ACU_PLGMFuncCfg -p c385ev
     python monitor.py --message ACU_PLGMFuncCfg
 ```
输出：
```
AVNT_PLGMCloseReqVD: Invalid
AVNT_PLGMCloseReq: No request
AVNT_PLGMOpenReqVD: Invalid
AVNT_PLGMOpenReq: No request
ACU_PLGMCtrl: 0
ACU_PLGMFuncCfg: Enable
ACU_PLGMTrunkReleaseReq: Not active
ACU_PLGMMaxPstReq: Not active


AVNT_PLGMCloseReqVD: Invalid
AVNT_PLGMCloseReq: No request
AVNT_PLGMOpenReqVD: Invalid
AVNT_PLGMOpenReq: No request
ACU_PLGMCtrl: 0
ACU_PLGMFuncCfg: Enable
ACU_PLGMTrunkReleaseReq: Not active
ACU_PLGMMaxPstReq: Not active


AVNT_PLGMCloseReqVD: Invalid
AVNT_PLGMCloseReq: No request
AVNT_PLGMOpenReqVD: Invalid
AVNT_PLGMOpenReq: No request
ACU_PLGMCtrl: 0
ACU_PLGMFuncCfg: Enable
ACU_PLGMTrunkReleaseReq: Not active
ACU_PLGMMaxPstReq: Not active
```
1.3 收到的信号实时绘制成散点图
```
     python monitor.py -l ACU_LDW_LKACfg --plot
     python monitor.py -l acu_ldw_lkacfg -l ACU_DrvModCfg -l ACU_PAS_ButtonPress --plot
     python monitor.py -lm ACU_PLGMFuncCfg --plot
```

1.4 周期发送单信号(支持多个值)
```
     python monitor.py -s BCS_VehSpd -v 10
     python monitor.py -s BCS_VehSpd -v 10,20
```
output:
```
+++++++++BCS_VehSpd:10+++++++++
value choices:null
message name: GW_BCS_2_B
frame_id(x): 608
channel: 1
Timestamp:        0.000000        ID: 0260    S                DLC:  8    00 00 00 00 00 b2 00 00

+++++++++BCS_VehSpd:20+++++++++
value choices:null
message name: GW_BCS_2_B
frame_id(x): 608
channel: 1
Timestamp:        0.000000        ID: 0260    S                DLC:  8    00 00 00 00 01 64 00 00
```

1.5 周期发送多信号
```
     python monitor.py -s BCS_VehSpdVD -v 1 -s BCS_VehSpd -v 100
```
output:
```
+++++++++{'BCS_VehSpdVD': '1', 'BCS_VehSpd': '100'}+++++++++
value choices:{"0": "Not Valid", "1": "Valid"}
message name: GW_BCS_2_B
frame_id(x): 608
channel: 1
Timestamp:        0.000000        ID: 0260    S                DLC:  8    00 00 00 00 26 f2 00 00
```

1.6 重复发送
```
     python monitor.py -s VCU_VehDrvMod -v 1 -r 10
     python monitor.py -s vcu_Vehdrvmod -v 1,2,3 -r 10
     python monitor.py -s BCS_VehSpdVD -v 1 -s BCS_VehSpd -v 100 -r 10
```
##2.linmonitor.py
LIN信号的发送接收工具, 基于plin_driver1.0.1
2.1 plin_driver 安装
```  cd peak-lin-driver-1.0.1
     make
     sudo make install
 ``` 
 安装完成后,执行如下命令验证驱动是否安装成功
 ```
    sudo modprobe plin 
    ls /sys/class/plin
 ``` 
 
2.2 接收Lin信号
使用方法:
```
     python linmonitor.py -l PM25_InDnst 
     python monitor.py -l PM25_InDnst -c 1 #指定监听通道,默认为channel 0
 ``` 
输出：
 ```
    PM25_InDnst --> 456      raw data:  38  c8 01 00 00 00 3c 00 00 
    PM25_InDnst --> 456      raw data:  38  c8 01 00 00 00 3c 00 00 
    PM25_InDnst --> 456      raw data:  38  c8 01 00 00 00 3c 00 00 
    PM25_InDnst --> 456      raw data:  38  c8 01 00 00 00 3c 00 00 
    PM25_InDnst --> 456      raw data:  38  c8 01 00 00 00 3c 00 00 
```
  
2.3 发送Lin信号
使用方法:
```
     python linmonitor.py -s PM25_InDnst -v 456 -s PM25_MsgRolgCnt -v 15 
     python monitor.py -s PM25_InDnst -v 456 -s PM25_MsgRolgCnt -v 15 -r 10 #指定重复发送次数
``` 
输出：
 ```
    ++++++++++++signal:value+++++++++++++
    {'PM25_InDnst': [456], 'PM25_ErrSts': [0], 'PM25_MsgRolgCnt': [15], 'PM25_RespErr': [0]}
    
    +++++++Raw Data for PLIN Driver (Total: 10 times, Interval: 0.2s)+++++++
    0x38 --data "0xc8 0x01 0x00 0x00 0x00 0x3c 0x00 0x00" /dev/plin1
 ```
  

##2.simulator.py
车控/空调app的信号模拟器。根据接收的信号模拟对手件给CDC设置返回信号.
```
     python simulator.py --ecu hvac
     python simulator.py --ecu carsettings
```
##3.did_editor.py
3.1 读did
 ```
       python did_editor.py -r 0x0100
 ```
3.2 写did
 ```
       python did_editor.py -w 0xF190 LMGNMT01901000080
       python did_editor.py -w 0x0101 66FFFFFFFFFFFFFFFFFFFFFFFFFFFFFF
       python did_editor.py -w 0x0110 FF
 ```
3.3 读取dtc/清除dtc
 ```
       python did_editor.py --dtc
       python did_editor.py --clear
 ```
3.4 ECU硬重启
 ```
       python did_editor.py --reset
 ```

##4.blf_editor.py
4.1 录制can信号(默认每600s录制一个blf文件)
 ```
       python blf_editor.py --record
       python blf_editor.py --record -d 100  每100s录制一个文件
 ```
4.2 回放can信号(支持过滤message)
 ```
       python blf_editor.py --replay a.blf
       python blf_editor.py --replay a.blf --filter 608,609,610
 ```
4.3 blf转换成csv
 ```
       python blf_editor.py --tocsv a.blf
       python blf_editor.py --tocsv a.blf --filter 608,609,610
 ```