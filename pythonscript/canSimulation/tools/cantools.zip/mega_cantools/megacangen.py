# -*- coding: utf-8 -*-
"""
A can Generate (random) CAN traffic to CDC
"""
import argparse
from mega_cantools_lib.parsers.monkey import _monkey

if __name__ == '__main__':
    parser = argparse.ArgumentParser(description='Generate (random) CAN traffic to CDC')

    parser.add_argument('--random',
                        help='Generating can frames with random values',
                        action='store_true')

    parser.add_argument('--time',
                        type=int,
                        help='terminate seconds',
                        default='600')

    parser.add_argument('--node',
                        help='sending node',
                        default='VCU,GW')

    parser.add_argument('--file',
                        help='store sending frames to file',
                        default='monkey.txt')

    parser.add_argument('--get',
                        help='get all node in dbc',
                        action='store_true')

    parser.add_argument('-p', '--project',
                        help='specify project, default is c385ev',
                        default='c385ev')

    parser.add_argument('-c', '--channel',
                        type=int,
                        help='specify can channel',
                        default=0)

    parser.add_argument('-rc', '--randomcycle',
                        help='random cycle time[0.5-2] for every frame',
                        action='store_true')

    args = parser.parse_args()
    _monkey(args)
